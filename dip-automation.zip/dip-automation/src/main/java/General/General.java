package General;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.ss.usermodel.Row.MissingCellPolicy;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.Select;

import cucumber.api.Scenario;

enum LocatorType {

	ID, XPATH, LINKTEXT, PARTIALLINKTEXT, NAME, TAGNAME, CLASSNAME, CSSSELECTOR

}

public class General {

	private static String downloadFilepath = System.getProperty("user.dir") + File.separator
			+ GetConfig.getConfigValue("DownloadFilepPath");

	/**
	 * 
	 * @see@param type
	 * @see@param locator
	 * @see @param driver
	 * @return
	 */
	public static WebElement findElement(LocatorType type, String locator, WebDriver driver) {
		WebElement element = null;

		switch (type) {

		case ID:
			element = driver.findElement(By.id(locator));
			break;
		case XPATH:
			element = driver.findElement(By.xpath(locator));
			break;
		case LINKTEXT:
			element = driver.findElement(By.linkText(locator));
			break;
		case PARTIALLINKTEXT:
			element = driver.findElement(By.partialLinkText(locator));
			break;
		case NAME:
			element = driver.findElement(By.name(locator));
			break;
		case TAGNAME:
			element = driver.findElement(By.tagName(locator));
			break;
		case CLASSNAME:
			element = driver.findElement(By.className(locator));
			break;
		case CSSSELECTOR:
			element = driver.findElement(By.cssSelector(locator));
			break;
		default:
			break;

		}

		return element;
	}

	/**
	 * @see waiting for element display
	 * @param driver
	 * @param second
	 */

	public static void WaitSecond(WebDriver driver, int second) {
		driver.manage().timeouts().implicitlyWait(second, TimeUnit.SECONDS);
	}

	/**
	 * @see check if the element is display
	 * @param element
	 * @return
	 */
	public static boolean isDisaply(WebElement element) {
		return element.isDisplayed();

	}

	/**
	 * @see this function add donwload path for chrome options
	 * @return Chrome options
	 */
	public static ChromeOptions setDownloadFilePathOption() {
		// ChromeOptions options=null;

		String downloadFilepath = System.getProperty("user.dir") + File.separator
				+ GetConfig.getConfigValue("DownloadFilepPath");
		HashMap<String, Object> chromePrefs = new HashMap<String, Object>();

		chromePrefs.put("profile.default_content_settings.popups", 0);
		chromePrefs.put("download.default_directory", downloadFilepath);
		ChromeOptions options = new ChromeOptions();
		options.setExperimentalOption("prefs", chromePrefs);
		options.setExperimentalOption("useAutomationExtension", false);
		return options;
	}

	/*
	 * 
	 */
	public static void CreateFileFolder() {
		File Directory = new File(downloadFilepath);

		if (!Directory.exists()) {
			Directory.mkdir();
			System.out.println("create the folder directly" + downloadFilepath);
		} else {
			Directory.delete();
			Directory.mkdir();
			System.out.println("Deleted the foder at frist,then create the folder" + downloadFilepath);
		}

	}

	/**
	 * @see wait for elment is visiable
	 * @param driver
	 * @param seconds
	 * @param locator
	 */

	public static void waitUntilvisiable(WebDriver driver, int seconds, By locator) {
		WebDriverWait wait = new WebDriverWait(driver, seconds);
		wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
	}

	/*
	 * private static String ActualFilePath; private static String ExpectFilePath;
	 */

	/**
	 * @See Read Excel file from the file path
	 * @author QXZ0M7S
	 * @param excelfilepath
	 * @return
	 * @throws FileNotFoundException
	 * @throws IOException
	 */

	public static ArrayList<List> ReadExcel(String excelfilepath) throws FileNotFoundException, IOException {

		ArrayList<List> list = new ArrayList<List>();
		File input = new File(excelfilepath);

		Workbook wb = null;

		wb = WorkbookFactory.create(input);

		DataFormatter formatter = new DataFormatter();
		org.apache.poi.ss.usermodel.Sheet sheet1 = wb.getSheetAt(0);
		for (Row row : sheet1) {
			ArrayList<String> listrow = new ArrayList<String>();
			for (Cell cell : row) {

				String value = null;
				switch (cell.getCellType()) {
				case STRING:
					value = cell.getRichStringCellValue().getString();

					break;
				case NUMERIC:
					if (DateUtil.isCellDateFormatted(cell)) {
						value = cell.getDateCellValue().toString();
					} else {
						value = String.valueOf(cell.getNumericCellValue());
					}
					break;
				case BOOLEAN:
					value = String.valueOf(cell.getBooleanCellValue());
					break;
				case FORMULA:
					value = cell.getCellFormula().toString();
					break;
				case BLANK:

					value = "empty";
					break;
				case _NONE:

					value = "_NONE";
					break;
				case ERROR:
					value = "ERROR";
					break;
				default:

				}
				listrow.add(value);
			}
			list.add(listrow);

		}
		return list;
	}

	/*
	 * public static ArrayList<List> ReadExcel1(String excelfilepath ) throws
	 * FileNotFoundException, IOException { MissingCellPolicy xRow = null;
	 * ArrayList<List> list=new ArrayList<List>(); File input=new
	 * File(excelfilepath);
	 * 
	 * Workbook wb=null;
	 * 
	 * wb = WorkbookFactory.create(input);
	 * 
	 * DataFormatter formatter = new DataFormatter();
	 * org.apache.poi.ss.usermodel.Sheet sheet1 = wb.getSheetAt(0);
	 * 
	 * int rowTotalCount=sheet1.getLastRowNum(); int columnCount=
	 * sheet1.getRow(0).getPhysicalNumberOfCells(); for(int
	 * i=sheet1.getFirstRowNum();i<rowTotalCount;i++) { Row row=sheet1.getRow(i);
	 * 
	 * ArrayList<String> listrow=new ArrayList<String>();
	 * 
	 * for(int j=0;j<columnCount;j++) { String cell=null;
	 * System.out.println(row.getCell(j,
	 * Row.MissingCellPolicy.RETURN_BLANK_AS_NULL)); if(null==row.getCell(j,
	 * Row.MissingCellPolicy.RETURN_BLANK_AS_NULL)) { cell="empty"; continue; } else
	 * { cell=row.getCell(j).toString();
	 * 
	 * } listrow.add(cell); } list.add(listrow); }
	 * 
	 * 
	 * return list; }
	 */

	/**
	 * 
	 * compareExcelfile
	 */

	public static void CompareExcel(String ActualFilePath, String ExpectFilePath) {
		try {
			ArrayList<List> actualList = ReadExcel(ActualFilePath);
			ArrayList<List> expectList = ReadExcel(ExpectFilePath);

			for (int i = 1; i <= actualList.size(); i++) {
				List actual = actualList.get(i - 1);
				List expect = expectList.get(i - 1);

				if (actual.size() > expect.size()) {
					System.out.println(
							String.format("fail----export report row data grant than actual report at row %d ", i));
				} else if (actual.size() < expect.size()) {
					System.out.println(
							String.format("fail----export report row data less than actual report at row %d ", i));
				} else {
					if (actual.equals(expect)) {
						System.out.println(String.format(
								"success----export report row data equals actual report row data at row %d ", i));
					} else {
						System.out.println(String
								.format("fail----export report row data didn't equals actual report at row %d ", i));
					}

				}
			}

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	/**
	 * @author LI
	 * @param driver by
	 * @return 001
	 */
	public static boolean isJudgingElement(WebDriver webDriver, By by) {
		try {
			webDriver.findElement(by);
			System.out.println("element is  exsting");
			return true;
		} catch (Exception e) {
			System.out.println("element is not exsting");
			return false;
		}
	}

	/**
	 * @author LI
	 * @param driver by
	 * @return 002
	 */
	public static boolean isAlertPresent(WebDriver driver) throws InterruptedException {
		try {
			driver.switchTo().alert();
			Thread.sleep(1000);
			return true;
		} catch (NoAlertPresentException e) {
			return false;
		}
	}

	/**
	 * 
	 * /** 007
	 * 
	 * @author LI
	 * @param driver
	 * @param by
	 * @return
	 * 
	 */
	public static Select select(WebDriver driver, By by) {

		WebElement element = driver.findElement(by);
		org.openqa.selenium.support.ui.Select select = new Select(element);
		return select;

	}

	/**
	 * 011
	 * 
	 * @author LI
	 * @param driver
	 * @param script
	 * @param by
	 */
	public static String getAttribute(WebDriver driver, By by, String name) {

		String value = driver.findElement(by).getAttribute(name);

		return value;

	}

	/**
	 * 012
	 * 
	 * @author qxz0n2l LI
	 * @param driver
	 * @param message
	 * @return
	 */
	public static void CheckAlertTextandcloseIt(WebDriver driver, String message) {

		Alert alert = driver.switchTo().alert();
		String alertText = alert.getText();
		boolean isacceptAlert = alertText.equals(message);

		if (isacceptAlert) {
			alert.accept();
		} else {
			alert.dismiss();
		}

	}

	/*    *//**
			 * 0013
			 * 
			 * @param driver
			 * @param isaccept
			 * @return
			 *//*
				 * 
				 * public static String closeAlertAndGetItsText(WebDriver driver, boolean
				 * isaccept) {
				 * 
				 * Alert alert = driver.switchTo().alert(); String alertText = alert.getText();
				 * if (isaccept) { alert.accept(); } else { alert.dismiss(); } return alertText;
				 * }
				 */

	/**
	 * 014
	 * 
	 * @author qxz0n2l LI
	 * @return
	 * @throws InterruptedException
	 */

	public static void isPresentCloseAlert(WebDriver driver, boolean isaccept) throws InterruptedException {

		if (General.isAlertPresent(driver)) {

			Alert alert = driver.switchTo().alert();

			if (isaccept) {
				alert.accept();
			} else {
				alert.dismiss();
			}
		}

	}

	/**
	 * 
	 * @param driver
	 * @param isaccept
	 * @throws InterruptedException
	 */

	public static String isPresentGetAlertext(WebDriver driver) throws InterruptedException {

		String alertText="";
		if (General.isAlertPresent(driver)) {

			Alert alert = driver.switchTo().alert();

			alertText = alert.getText();
		}
		return alertText;

	}

	

	/**
	 * 003
	 * 
	 * @author LI
	 * @param driver by
	 * @return
	 * @throws InterruptedException 
	 */
	public static void sendKeys(WebDriver driver, By by, CharSequence... keysToSend) throws InterruptedException {
		driver.findElement(by).clear();
		Thread.sleep(3000);
		driver.findElement(by).sendKeys(keysToSend);
	}

	/**
	 * 004
	 * 
	 * @author LI
	 * @param driver by
	 * 
	 */

	public static void click(WebDriver driver, By by) {

		driver.findElement(by).click();
	}

	/**
	 * 005
	 * 
	 * @author LI
	 * @param driver
	 * @param by
	 * 
	 */
	public static void switchToWindow(WebDriver driver) {

		Set<String> handles = driver.getWindowHandles();
		String currentHandle = driver.getWindowHandle();
		// System.out.println("currentHandle:"+currentHandle);
		System.out.println("handlesize:" + handles.size());
		int size = handles.size();

		for (String handle : handles) {
			System.out.println(handle);// print handles

			if (!handle.equals(currentHandle)) {
				System.out.print("switchToWindow:" + handle);
				driver.switchTo().window(handle);
				break;
			}
		}
	}

	/**
	 * 006
	 * 
	 * @author LI
	 * @param driver
	 * @param by
	 * 
	 */
	public static void maxWindow(WebDriver driver) {
		driver.manage().window().maximize();
	}

	/**
	 * 007
	 * 
	 * @author LI
	 * @param driver
	 * @param by
	 * @return
	 * 
	 */
	public static Select elect(WebDriver driver, By by) {

		WebElement element = driver.findElement(by);
		org.openqa.selenium.support.ui.Select select = new Select(element);
		return select;

	}

	/**
	 * 008
	 * 
	 * @author LI
	 * @param driver
	 * @param by
	 */
	public static String getText(WebDriver driver, By by) {
		String text = driver.findElement(by).getText();
		return text;
	}

	/**
	 * 009
	 * 
	 * @author LI
	 * @param driver
	 * @param by
	 */
	public static void switchToFrame(WebDriver driver, By by) {
		WebElement frameElement = driver.findElement(by);
		driver.switchTo().frame(frameElement);
	}

	/**
	 * 010
	 * 
	 * @author LI
	 * @param driver
	 * @param script
	 * @param by
	 */
	public static void executeScript(WebDriver driver, String script, By by) {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript(script, driver.findElement(by));
	}

	/**
	 * @param driver
	 * @param element Whether the element is existing or not
	 */
	public static boolean JudgingElementByText(WebDriver driver, String element) {
		try {
			driver.findElement(By.linkText(element));
			return true;
		} catch (Exception e) {
			System.out.println("The element is not existing.");
			return false;
		}
	}

	/**
	 * @param driver
	 * @param element Whether the element is existing or not
	 */
	public static boolean JudgingElementByContainsText(WebDriver driver, String text) {
		try {
			driver.findElement(By.xpath("//a[contains(text(),\'" + text + "\')]"));
			return true;
		} catch (Exception e) {
			// System.out.println("The element is not existing.");
			return false;
		}
	}

	/**
	 * @param driver
	 * @param element Whether the element is existing or not
	 */
	public static boolean JudgingElementById(WebDriver driver, String id) {
		try {
			driver.findElement(By.id(id));
			return true;
		} catch (Exception e) {
			// System.out.println("The id is not existing.");
			return false;
		}

	}

	/**
	 * @param driver
	 * @param element Whether the element is existing or not
	 */
	public static boolean JudgingElementBy(WebDriver driver, By by) {
		try {
			driver.findElement(by);
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	public static void cleanFolder(String path) {
		File file = new File(path);
		if (file == null || !file.exists()) {
			file.mkdir();
		} else {
			deleteFiles(file);
			file.mkdir();
		}
	}

	public static void deleteFiles(File subFile) {
		File[] fileList = subFile.listFiles();
		for (File f : fileList) {
			if (f.isDirectory()) {
				deleteFiles(f);
			} else {
				f.delete();
			}
		}
		subFile.delete();
	}
	
	public static void runToolWithCmd(String toolPath, String saveFilePath,String fileCategory) throws InterruptedException {
		Runtime downloadexe = Runtime.getRuntime();
		try {
			cleanFolder(saveFilePath);
			downloadexe.exec("C:/Windows/System32/cmd.exe /k start "+toolPath+" "+saveFilePath+fileCategory.replaceAll(" ", "").replaceAll("-", "")+"TemplateNew.xlsx"); // Download file
			Thread.sleep(10000);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public static void closeAlertAndGetItsText(WebDriver driver, boolean acceptNextAlert) {
		try {
			Alert alert = driver.switchTo().alert();
			if (acceptNextAlert) {
				alert.accept();
			} else {
				alert.dismiss();
			}
		} finally {
			acceptNextAlert = true;
		}
	}
	
}
