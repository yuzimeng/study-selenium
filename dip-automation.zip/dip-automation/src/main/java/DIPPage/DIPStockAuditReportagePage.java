package DIPPage;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import General.General;
import cucumber.api.java.en.Then;


public class DIPStockAuditReportagePage extends BasePage {

	public DIPStockAuditReportagePage(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}
	
	
	public void clicktheIconofStockAuditReport() throws InterruptedException {
		
		General.executeScript(driver, "arguments[0].click();", By.id("MenuTree_link_41"));
		Thread.sleep(10000);
		driver.switchTo().defaultContent();	
		Thread.sleep(1000);
		General.switchToFrame(driver, By.name("fraInterface"));
	}
	
	public void  selectthevalueofYearMonthatDealerManagementoftheatStockAuditReportPage(String yearmonth) throws InterruptedException {
		
		System.out.println("hahah"+General.getAttribute(driver, By.name("YearMonth1"), "value"));
		
		General.sendKeys(driver, By.name("YearMonth1"), yearmonth);
		
		
	}
	
	public void clickthebuttonofCalculationattheatStockAuditReportPage() {
		
		General.executeScript(driver, "arguments[0].click", By.xpath("//*[value='Calculation']"));
				
	}
	
	public void clickthebuttonofExportattheatStockAuditReportPage() {
		
		General.executeScript(driver, "arguments[0].click", By.xpath("//*[value='Calculation']"));
	}
	
	

	
}
