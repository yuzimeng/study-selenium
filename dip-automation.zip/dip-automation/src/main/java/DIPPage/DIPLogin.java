package DIPPage;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;

import General.General;
import General.GetConfig;

public class DIPLogin extends BasePage {

	private By user = By.name("UserCode");
	private By password = By.name("password_PWD");
	private By button = By.name("submit2");
	private By loginFrame = By.name("fraInterface");
	/*
	 * WebElement frameUser= driver.findElement(By.name("fraInterface"));
	 * driver.switchTo().frame(frameUser);
	 * driver.findElement(By.name("UserCode")).sendKeys("DIPTEST");
	 */

	public DIPLogin(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}
	String usernamevalue = GetConfig.getConfigValue("DIPUserName");
	String pwdvalue = GetConfig.getConfigValue("DIPPassword");
	String DIPSiteURL = GetConfig.getConfigValue("DIPURL");

	public void login() throws InterruptedException {
		
		General.maxWindow(driver);
		driver.get(DIPSiteURL);
		Thread.sleep(10000);

		driver.switchTo().frame(this.driver.findElement(loginFrame));
		driver.findElement(user).sendKeys(usernamevalue);
		driver.findElement(password).sendKeys(pwdvalue);
		Thread.sleep(4000);
		Actions action = new Actions(driver);
		action.moveToElement(driver.findElement(By.name("submit2"))).perform();
		Thread.sleep(4000);
		General.executeScript(driver, "arguments[0].click();", By.name("submit2"));
		Thread.sleep(10000);
		
		/*
		 * General.maxWindow(driver); Thread.sleep(4000); General.switchToFrame(driver,
		 * By.name("fraInterface")); General.sendKeys(driver, user, usernamevalue);
		 * General.WaitSecond(driver, 10); General.sendKeys(driver, password, pwdvalue);
		 * General.WaitSecond(driver, 10); Actions action = new Actions(driver);
		 * action.moveToElement(driver.findElement(By.name("submit2"))).perform();
		 * Thread.sleep(4000); General.executeScript(driver, "arguments[0].click();",
		 * By.name("submit2")); Thread.sleep(10000); driver.switchTo().defaultContent();
		 */

	}


	public void visitDIPSite() throws InterruptedException {
		General.maxWindow(driver);
		driver.get(DIPSiteURL);
		Thread.sleep(10000);
	//	Thread.sleep(3000);

	}

	public void inputUsername() throws InterruptedException {
		driver.switchTo().frame(driver.findElement(loginFrame));
		driver.findElement(user).sendKeys(usernamevalue);
		Thread.sleep(1000);
	}

	public void inputPassword() throws InterruptedException {
		driver.findElement(password).sendKeys(pwdvalue);
		Thread.sleep(1000);
	}

	public void clickloginButton() throws InterruptedException {
		Actions action = new Actions(driver);
		action.moveToElement(driver.findElement(button)).perform();
		Thread.sleep(4000);
		General.executeScript(driver, "arguments[0].click();", button);
		System.out.println("clicked");
		Thread.sleep(10000);
		//driver.switchTo().defaultContent();
	}

}
