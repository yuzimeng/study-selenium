package DIPPage;

import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;

import General.General;

public class DIPDealerManagermentPage extends BasePage{

	
	public DIPDealerManagermentPage(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}
	

	public void UnfoltheDealerManagement() {
			
		General.executeScript(driver, "arguments[0].click();", By.id("MenuTree_link_12"));	
		
	}

	public void clicktheIconDealerManagement(){
		
		General.executeScript(driver, "arguments[0].click();", By.id("MenuTree_link_26"));
		driver.switchTo().defaultContent();		
	}
	
	public void inputtheNSCCode(String nsc) throws InterruptedException {
		 General.switchToFrame(driver, By.name("fraInterface")); 
	        Thread.sleep(10000);	
			General.sendKeys(driver, By.name("NSCcode"), nsc);			
	}
	
	public void clickthebuttonofSearchintheDealerManagementpage() {
		
		General.executeScript(driver, "arguments[0].click();", By.xpath("//*[ @value=\"Search\"]"));
	}
	
	public void doubleclickthevalueofSystemCode() throws InterruptedException {
		Actions action =new Actions(driver);
		action.moveToElement(driver.findElement(By.xpath("//*[@name='PolGrid1'and @id='PolGrid1r1']")));
		Thread.sleep(10000);
		action.doubleClick(driver.findElement(By.xpath("//*[@name='PolGrid1'and @id='PolGrid1r1']"))).perform();
		Thread.sleep(5000);
		
		driver.switchTo().defaultContent();	
        Set<String>handles = driver.getWindowHandles();
        String currentHandle = driver.getWindowHandle();
    //   System.out.println("currentHandle:"+currentHandle);
        System.out.println("handlesize:"+handles.size());
		
		
	}
	
	public void clickthebuttonofOKatthePopupbox() throws InterruptedException {
		
		 General.switchToWindow(driver);
		  System.out.println("切换窗口"); 
	//	General.switchToFrame(driver, By.name("fraInterface"));      
	      Thread.sleep(1000);
	      General.maxWindow(driver);
	      General.executeScript(driver, "arguments[0].click", By.name("StatusName"));
	      
	}
	
	public void changethestatus() throws InterruptedException {
		
		String value =General.getAttribute(driver, By.name("StatusName"), "value");
		   
		   if(value=="Valid") {
			   General.executeScript(driver, "arguments[0].value='Invalid';", By.name("StatusName"));
			   Thread.sleep(1000);	   
		   }else {
			   General.executeScript(driver, "arguments[0].value='Valid';", By.name("StatusName"));
			   Thread.sleep(1000);
		   }	 
	}
	
	public void clickthebuttonofConfirm() {
		
		General.executeScript(driver, "arguments[0].click", By.xpath("//*[@value='Confirm']"));
	}
	
	public String showthepopupandclickOK() throws InterruptedException {
		
		String message=General.isPresentGetAlertext(driver);
				General.isPresentCloseAlert(driver, true);
		   System.out.println(message+"******");
		   Thread.sleep(1000);
		String   statusvalue =General.getAttribute(driver, By.name("StatusName"), "value");
		
		return statusvalue;
	}


	
	
	
	
}
