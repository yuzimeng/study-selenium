package DIPPage;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import General.General;

public class DIPPaymentRatingPage extends BasePage {

	public DIPPaymentRatingPage(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}
	
	public void unfoldtheExport() {
		
		General.executeScript(driver, "arguments[0].click();", By.linkText("Export"));
	}
	
	
	public void clicktheIconofPaymentRating() throws InterruptedException {
		General.executeScript(driver, "arguments[0].click();", By.linkText("Payment Rating"));
		Thread.sleep(1000);
		driver.switchTo().defaultContent();
	}
	
	public void selectthevalueofYearMonth(String yearmonth) throws InterruptedException {
		
	    General.switchToFrame(driver, By.name("fraInterface"));
	    Thread.sleep(1000);
	    General.sendKeys(driver, By.name("YearMonth"), yearmonth);
	}
	
	public void inputtheNSCCod(String nsc) throws InterruptedException {
		
		//	General.getAttribute(driver, By.xpath("//input[@name='NSC_CODE' and @class='common' ]"), "name");
	    General.sendKeys(driver, By.xpath("//input[@name='NSC_CODE'and @class='common']"), nsc);	
	}
	
	public void clickthebuttonofSearch() {
		General.executeScript(driver, "arguments[0].click();", By.xpath("//*[@value='Search'][1]"));
		
	}
	
	public void inputtheDealerShortName(String dealershortname) throws InterruptedException {
		
		 General.sendKeys(driver, By.xpath("//input[@name='DealerShortName'and @class='common']"), dealershortname);
	}
	
	public void doubleclicktheRatingtextboxandselectonekindsofrating(String rating) throws InterruptedException {
		 General.executeScript(driver, "arguments[0].removeAttribute('readOnly');",By.xpath("//input[@name='Rating'and @class='codename']"));
		    Thread.sleep(1000);
		    General.sendKeys(driver, By.xpath("//input[@name='Rating'and @class='codename']"), rating);
	}
	
	public void  clickthebuttonofCalculation() throws InterruptedException {
		
		General.executeScript(driver, "arguments[0].click();", By.xpath("//*[@value='Calculation']"));
	    
	}

	/*
	 * public String isPresentgetAlertText() throws InterruptedException {
	 * 
	 * String message=null; if(General.isAlertPresent(driver)) {
	 * 
	 * message=General.closeAlertAndGetItsText(driver, true);
	 * 
	 * Thread.sleep(10000); return message; } return message; }
	 */

	public void clickthebuttonofPointsExport() {
		
		General.executeScript(driver, "arguments[0].click();",By.xpath("//*[contains(@value,'5-7')]"));
	}
	
	

	public String afterclickCalculation(WebDriver driver) throws InterruptedException {
		// TODO Auto-generated method stub
		String	message	=General.isPresentGetAlertext(driver);
        Thread.sleep(10000);
	    General.isPresentCloseAlert(driver, true);
	   Thread.sleep(1000);
	  return message;
	}
	
	public String afterclickExport(WebDriver driver) throws InterruptedException {
		// TODO Auto-generated method stub
		String	message	=General.isPresentGetAlertext(driver);
        Thread.sleep(10000);
	    General.isPresentCloseAlert(driver, true);
	   Thread.sleep(1000);
	  return message;
	}
	

}
