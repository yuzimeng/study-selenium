package DIPPage;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import General.General;

public class DIPStockAuditRatingPage extends BasePage {

	public DIPStockAuditRatingPage(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}
	
	public void unfoldtheDIP() {
		
		General.executeScript(driver, "arguments[0].click();", By.linkText("DIP"));
	}
	
	public void unfoldtheRegularImport() {
		
		General.executeScript(driver, "arguments[0].click();", By.linkText("Regular Import"));
	}
	
	public void clicktheIconofStockAuditRating() {
		General.executeScript(driver, "arguments[0].click();", By.linkText("Stock Audit Rating"));
	}
	
	public void clickthebuttonofImportTemplateDownloadattheCreditAcceptanceofStockAuditRatingpage() throws InterruptedException {
		 
		 Thread.sleep(1000);		
		General.executeScript(driver, "arguments[0].click();", By.xpath("//*[@value=\"Import Template Download\"]"));
	}
	
	
	
}
