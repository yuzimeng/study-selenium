package DIPPage;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;

public class BasePage {
	
	protected  WebDriver driver=null;
	
	public BasePage(WebDriver driver)
	{
		this.driver=driver;
	}
	/**
	 * max current window
	 */
	public void maxWindow()
	{
		this.driver.manage().window().maximize();
		
	}
	
	/**
	 * @see get current url of this page
	 * @return
	 */
	public String getURL()
	{
		return this.driver.getCurrentUrl();
	}
	

	/**
	 * @author LI
	 * @param driver by
	 * @return 001
	 */
	public  boolean isJudgingElement(WebDriver webDriver, By by) {
		try {
			webDriver.findElement(by);
			System.out.println("element is  exsting");
			return true;
		} catch (Exception e) {
			System.out.println("element is not exsting");
			return false;
		}
	}
	
	
	
	
	
	
	
	

}
