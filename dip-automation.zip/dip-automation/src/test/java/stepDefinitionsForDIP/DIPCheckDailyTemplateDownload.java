package stepDefinitionsForDIP;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;

public class DIPCheckDailyTemplateDownload {
	
	WebDriver driver=Hook.getDriver();
	
	@When("^Click the Icon of Daily Import-Portfolio \"([^\"]*)\"$")
	public void click_the_Icon_of_Daily_Import_Portfolio(String importCategory) throws Throwable {
		if (General.General.JudgingElementByContainsText(driver, importCategory))
		{
			String dailyImportPortfolioId = driver.findElement(By.xpath("//a[contains(text(),\'" + importCategory + "\')]")).getAttribute("id");
			System.out.println("Daily import Portfolio Id:" + dailyImportPortfolioId);
			driver.findElement(By.id(dailyImportPortfolioId)).sendKeys(Keys.ENTER);
		}
		Thread.sleep(5000);
		driver.switchTo().defaultContent();
		
		driver.switchTo().frame("fraInterface");
		
	}

}
