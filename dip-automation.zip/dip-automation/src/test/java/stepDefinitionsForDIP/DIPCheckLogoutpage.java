package stepDefinitionsForDIP;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import General.General;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import junit.framework.Assert;

public class DIPCheckLogoutpage {
	
	
	WebDriver driver=Hook.getDriver();
	/*
	 * DIP_003_ChecktheSearchfounctionbytheNSCCode  @RFS-57
	 * Given Login the DIP system
	 */

	@When("^Click the button of Log out$")
	public void click_the_button_of_Log_out() throws Throwable {
		  //driver.switchTo().defaultContent();
		  //driver.switchTo().frame("fraMenu");
			  
		  General.executeScript(driver, "arguments[0].click();", By.linkText("Log out"));
		  Thread.sleep(10000);
		  
		  driver.switchTo().defaultContent();
		  General.switchToFrame(driver, By.name("fraInterface"));
	}
	
	@Then("^Back to the Login page$")
	public void back_to_the_Login_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		
		Assert.assertEquals(General.getAttribute(driver,By.name("password_PWD"), "name"), "password_PWD");
		
		
	    
	}

	
}
