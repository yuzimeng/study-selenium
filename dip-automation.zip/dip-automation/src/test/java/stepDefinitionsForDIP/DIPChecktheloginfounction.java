package stepDefinitionsForDIP;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import DIPPage.DIPLogin;
import General.General;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import junit.framework.Assert;

public class DIPChecktheloginfounction {
	
	     WebDriver driver = Hook.getDriver();
	     DIPLogin login=new DIPLogin(driver);
	     
	@Given("^Access the DIP system with url \"([^\"]*)\"$")
	public void access_the_DIP_system_with_url(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		 login.visitDIPSite();
		 Thread.sleep(1000);
	    
	}
	
	@When("^Input the Login Name$")
	public void input_the_Login_Name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   login.inputUsername();
	   Thread.sleep(1000);
	}
	
	@When("^Input the Password$")
	public void input_the_Password() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	  login.inputPassword();
	  Thread.sleep(10000);
	}
	
	@When("^Click the button of Login$")
	public void click_the_button_of_Login() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    login.clickloginButton();
	    Thread.sleep(10000);
	    driver.switchTo().defaultContent();
		driver.switchTo().frame("fraMenu");
	}
	@Then("^Enter the Welcome page successfully$")
	public void enter_the_Welcome_page_successfully() throws Throwable {
			
	boolean result=	General.getText(driver, By.linkText("System Home Page")).equals("System Home Page");
		
		Assert.assertTrue(result);
		
		
		System.out.println(General.getText(driver, By.linkText("System Home Page")));
	
	}

}
