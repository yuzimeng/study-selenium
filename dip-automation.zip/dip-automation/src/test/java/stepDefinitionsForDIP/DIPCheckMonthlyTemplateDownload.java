package stepDefinitionsForDIP;

import java.io.File;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class DIPCheckMonthlyTemplateDownload {

	WebDriver driver = Hook.getDriver();

	@Given("^Click the Icon of Monthly Import-Portfolio \"([^\"]*)\"$")
	public void click_the_Icon_of_Mothly_Import_Portfolio(String importCategory) throws Throwable {
		if (General.General.JudgingElementByContainsText(driver, importCategory)) {
			String monthlyImportPortfolioId = driver
					.findElement(By.xpath("//a[contains(text(),\'" + importCategory + "\')]")).getAttribute("id");
			//System.out.println("Monthly import Portfolio Id:" + monthlyImportPortfolioId);
			driver.findElement(By.id(monthlyImportPortfolioId)).sendKeys(Keys.ENTER);
		} else {
			throw new Exception("Excute failed."); //This file does not show in this page.
		}
		Thread.sleep(2000);
		driver.switchTo().defaultContent();
		driver.switchTo().frame("fraInterface");
		Thread.sleep(3000);
	}

	@When("^Click the \\[Import Template Download\\] button$")
	public void click_the_Import_Template_Download_button_for_Month() throws Throwable {
		By importTemplateDownload = By.xpath("//input[@class='cssButton' and @value='Import Template Download']");

		WebElement selectOption = driver.findElement(importTemplateDownload);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].click();", selectOption);
		Thread.sleep(3000);
	}

	@Then("^Verify the Excel has been downloaded$")
	public void verify_the_Excel_has_been_downloaded() throws Throwable {
		File file = new File(Hook.getDownloadPath());
		if (file.isDirectory()) {
			if (file.list().length > 0) {
				System.out.println("Verify Export monthly report Portfolio successfully.");
			} else {
				throw new Exception("Verify Export monthly report Portfolio failed.");
			}
		} else {
			throw new Exception("Verify the directory whether it is not existing.");
		}
	}

}
