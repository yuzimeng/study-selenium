package stepDefinitionsForDIP;

import java.io.File;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import DIPPage.DIPLogin;
import DIPPage.DIPStockAuditRatingPage;
import General.General;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class DIPCheckStockAuditRatingPage {

	/*
	 * @RFS-62
	 * 
	 */

	WebDriver driver = Hook.getDriver();
	DIPStockAuditRatingPage sar = new DIPStockAuditRatingPage(driver);

	// DIP_002_ChecktheImportTemplateDownloadfounction @RFS-62
	/*
	 * @RFS-30 Feature: DIP-Automation-Story
	 * 
	 * #step1: Login the DIP system # step2: Unfold the DIP # step3: Unfold
	 * theRegular Import # step4: Click the Icon of Stock Audit Rating # step5:
	 * Click the button of Import Template Download at the Credit Acceptance of
	 * Stock Audit Rating page # step6: Click the button of save as
	 * "ImpportStockAuditRating" at the Pop_up box  # expected result: There is a
	 * Excel was downloaded
	 * 
 @RFS-62 Scenario Outline: DIP-AutoTC-Stock Audit Rating page-Check the Import Template Download founction of Credit Acceptance
	 *  Given Login the DIP system
	 * When Unfold the DIP 
	 * And Unfold the Regular Import 
	 * And Click the Icon of Stock Audit Rating
	 * And Click the button of Import Template Download at the Credit Acceptance of Stock Audit Rating page 
	 * And Click the button of Save as"<importtemplatedownload>"at the Pop_up box 
	 * Then There is a Excel was downloaded
	 * Examples:
	 *  |importtemplatedownload | 
	 *  |ImpportStockAuditRating|
	 */
	@Given("^Login the DIP system$")
	public void login_the_DIP_system() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		DIPLogin login = new DIPLogin(driver);
		login.login();
		driver.switchTo().defaultContent();
		Thread.sleep(1000);
		driver.switchTo().frame("fraMenu");
		// General.switchToFrame(driver, By.name("fraMenu"));
		Thread.sleep(1000);
	}

	@When("^Unfold the DIP$")
	public void unfold_the_DIP() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		// General.switchToFrame(driver, By.name("fraMenu"));
		sar.unfoldtheDIP();
		Thread.sleep(10000);

	}

	@When("^Unfold the Regular Import$")
	public void unfold_the_Regular_Import() throws Throwable {

		sar.unfoldtheRegularImport();
		Thread.sleep(10000);
	}

	@When("^Click the Icon of Stock Audit Rating$")
	public void click_the_Icon_of_Stock_Audit_Rating() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		sar.clicktheIconofStockAuditRating();
		Thread.sleep(10000);
		driver.switchTo().defaultContent();
		General.switchToFrame(driver, By.name("fraInterface"));
		Thread.sleep(3000);
		
	}

	@When("^Click the button of Import Template Download at the Credit Acceptance of Stock Audit Rating page$")
	public void click_the_button_of_Import_Template_Download_at_the_Credit_Acceptance_of_Stock_Audit_Rating_page()
			throws Throwable {

		sar.clickthebuttonofImportTemplateDownloadattheCreditAcceptanceofStockAuditRatingpage();
		Thread.sleep(10000);
	}

	@When("^Click the button of Save as \"([^\"]*)\"at the Pop_up box$")
	public void click_the_button_of_Save_as_at_the_Pop_up_box(String reportname) throws Throwable {
		Runtime downloadexe = Runtime.getRuntime();
		try {
			General.cleanFolder(Hook.getDownloadPath());
			downloadexe.exec("C:/Windows/System32/cmd.exe /k start "+Hook.getDownloadTool() + " "+Hook.getDownloadPath()+reportname.replaceAll(" ", "").replaceAll("-", "") + "TemplateNew.xlsx"); // Download																											// file
			Thread.sleep(10000);
		} catch (IOException e) {
			e.printStackTrace();
		}
		Thread.sleep(10000);
	}

	@Then("^There is a Excel was downloaded$")
	public void there_is_a_Excel_was_downloaded() throws Throwable {
		File file = new File(Hook.getDownloadPath());
		if (file.isDirectory()) {
			if (file.list().length > 0) {
				System.out.println("Verify Export report file successfully.");
			} else {
				throw new Exception("Verify Export monthly report Portfolio failed.");
			}
		} else {
			throw new Exception("Verify the directory whether it is not existing.");
		}

	}
	
	/*
	 * DIP_032_RFS64_StockAuditRatingPage_ChecktheImportTemplateDownloadfounctionatDealerManagementofStockAuditRatingPage.feature
	 @RFS-30
Feature: DIP-Automation-Story

	#step1: Login the DIP system
	#step2: Unfold the DIP
	#step3: Unfold the Regular Import
	#step4: Click the Icon of Stock Audit Rating
	#step5: Click the button of Import Template Download at the Dealer Management page
	#step6: Click the button of Open at the Pop_up box
	#expected result: There is a Excel was opened
	@RFS-64
	Scenario outline: DIP-AutoTC-Stock Audit Rating page-Check the Import Template Download founction at Dealer Management of Stock Audit Rating page
		Given Login the DIP system
		When Unfold the DIP
		And Unfold the Regular Import
		And Click the Icon of Stock Audit Rating
		And Click the button of Import Template Download at Dealer Management of Stock Audit Rating page
		And Click the button of Save as "<importtemplatedownload>"at the Pop_up box
		Then There is a Excel was downloaded
		
		Examples:
       |importtemplatedownload                   |
	   |ImpportDealerManagementofStockAuditRating| 
	 * */
	
	/*
	   Given Login the DIP system
		When Unfold the DIP
		And Unfold the Regular Import
		And Click the Icon of Stock Audit Rating 
	 * */

	@When("^Click the button of Import Template Download at Dealer Management of Stock Audit Rating page$")
	public void click_the_button_of_Import_Template_Download_at_Dealer_Management_of_Stock_Audit_Rating_page() throws Throwable {
	    General.executeScript(driver, "arguments[0].click();", By.xpath("//*[@value='Import Template Download' and @onclick='download1();']"));
	    Thread.sleep(3000);
	}
	/*
	    And Click the button of Save as "<importtemplatedownload>"at the Pop_up box
		Then There is a Excel was downloaded 
	 * */
	
	/*
	 * DIP_034_RFS67_StockAuditRatingpage_ChecktheImportfounctionatDearlerManagementofStockAuditRatingpage.feature
	@RFS-30
Feature: DIP-Automation-Story

	#step1: Login the DIP system
	#step2: Unfold the DIP
	#step3: Unfold the Regular Import
	#step4: Click the Icon of Stock Audit Rating
	#step5: Select the value of Year Month at the Dearler Management page
	#step6: Click the button of Browser at the Dearler Management page
	#step7: Select one file that you want to import at the Dearler Management page
	#step8: Click the button of Import at the Dearler Management page
	#step9: Click the button of OK at the Pop_up box
	#expected result: You can find the file that you have imported in the Reminder Information list at the Dearler Management page
	@RFS-67
	Scenario Outline: DIP-AutoTC-Stock Audit Rating page-Check the Import founction at Dearler Management of Stock Audit Rating page
		Given Login the DIP system
		When Unfold the DIP
		And Unfold the Regular Import
		And Click the Icon of Stock Audit Rating
		And Select the value of Year Month "<yearmonth>" at Dearler Management of Stock Audit Rating page
		And Click the button of Browser at Dearler Management of Stock Audit Rating page
		And select your file that you want to import "<ImportReport>"
		And Click the button of Import at Dearler Management of Stock Audit Rating page
		And Click the button of Ok at the Pop_up box 
		Then We can see one file was named "<ImportReport>" in the Reminder Information at Dearler Management of Stock Audit Rating page
		
	Examples:
       |yearmonth  |ImportReport                            |
	   |2019-09    |DealerManagementofStockAuditRating.xlsx | 
	 * */
	
	/*
	   Given Login the DIP system
		When Unfold the DIP
		And Unfold the Regular Import
		And Click the Icon of Stock Audit Rating 
	 * */
	@When("^Select the value of Year Month \"([^\"]*)\" at Dearler Management of Stock Audit Rating page$")
	public void select_the_value_of_Year_Month_at_Dearler_Management_of_Stock_Audit_Rating_page(String yearmonth) throws Throwable {
	   
		General.sendKeys(driver, By.name("YearMonth1"), yearmonth);
		Thread.sleep(3000);
		
	}
	
	@When("^Click the button of Browser at Dearler Management of Stock Audit Rating page$")
	public void click_the_button_of_Browser_at_Dearler_Management_of_Stock_Audit_Rating_page() throws Throwable {
	    Actions action =new Actions(driver);
	    WebElement  browserbtn =driver.findElement(By.name("FileName1"));
	    action.moveToElement(browserbtn);
	    Thread.sleep(3000);
	    action.doubleClick().perform();
	    Thread.sleep(3000);
	}
	
	//And select your file that you want to import "<ImportReport>"
	
	@When("^Click the button of Import at Dearler Management of Stock Audit Rating page$")
	public void click_the_button_of_Import_at_Dearler_Management_of_Stock_Audit_Rating_page() throws Throwable {
	    General.executeScript(driver, "arguments[0].click();", By.xpath("//*[@onclick='Import1();' and @value='Import']")); 
	    Thread.sleep(3000);
	}
	
	@Then("^We can see one file was named \"([^\"]*)\" in the Reminder Information at Dearler Management of Stock Audit Rating page$")
	public void we_can_see_one_file_was_named_in_the_Reminder_Information_at_Dearler_Management_of_Stock_Audit_Rating_page(String ImportReport) throws Throwable {
	    
		   //click last page button	
			  By lastPageBtn = By.xpath("//img[@name='btnchangepage' and @src='https://dip-test.bmwgroup.net/dip-test/common/images/lastPage.gif']");
			  WebElement clickLastPageBtn = driver.findElement(lastPageBtn);
			  JavascriptExecutor js = (JavascriptExecutor) driver;
			  js.executeScript("arguments[0].click();", clickLastPageBtn);
			  General.isPresentCloseAlert(driver, true);// if there is only one page
			  Thread.sleep(5000);
			 

			By tableField = By.xpath("(//*[@name='ImportInfo1Grid2'])[last()]"); //@class='mulreadonly' and 
			String lineOneData = driver.findElement(tableField).getAttribute("value");
			
			if (lineOneData != "") {
				if (lineOneData.indexOf(ImportReport) != -1) {
					System.out.println("Verify Import Report successfully.");
				} else {
					throw new Exception("Verify Import Report failed.");
				}
			} else {
				throw new Exception("Import Import Report failed.");
			}
	}
	
}
