package stepDefinitionsForDIP;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

import General.General;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class CheckAMLCheckingExportPage {
	WebDriver driver=Hook.getDriver();
	
	/*
	 * DIP_026_RFS83_AMLCheckingExportpage_ChecktheAMLCheckfunctionwithCorporatescope.feature
@RFS-30
Feature: DIP-Automation-Story

	#step1: Login the DIP system
	#step2: Unfold the DIP
	#step3: Unfold the Export
	#step4: Click the Icon of AML Checking Export
	#step5: Select the value of YearMonthDay
	#step6: Double click the select box of CheckScope
	#step7: Select the Corporate scope
	#step8: Click the button of AML Check
	#expected result: The AML Check data show the current page and the Entity Type with Corporate
	#
	#
	@RFS-83
	Scenario Outline: DIP-AutoTC-AML Checking Export page-Check the AML Check function with Corporate scope
		Given Login the DIP system
		When Unfold the DIP
		And Unfold the Export
		And Click the Icon of AML Checking Export
		And Select the value of YearMonthDay "<yearmonthday>" at AML Check of AML Checking Export page
		And Double click the select box of CheckScope at AML Check of AML Checking Export page
		And Select the "<checkscope>" scope at AML Check of AML Checking Export page
		And Click the button of AML Check at AML Check of AML Checking Export page
		Then The AML Check data show the current page and the Entity Type with "<entitytype>"
		
	Examples:
     |yearmonthday  |checkscope   |entitytype|
	 |2019-11-07    |cop-Corporate|Corporate |
	 * */
	@When("^Click the Icon of AML Checking Export$")
	public void click_the_Icon_of_AML_Checking_Export() throws Throwable {
	    General.executeScript(driver, "arguments[0].click();", By.linkText("AML Checking Export"));
	    Thread.sleep(3000);
	    driver.switchTo().defaultContent();
	    driver.switchTo().frame("fraInterface");
	    Thread.sleep(3000);
	}
	
	@When("^Select the value of YearMonthDay \"([^\"]*)\" at AML Check of AML Checking Export page$")
	public void select_the_value_of_YearMonthDay_at_AML_Check_of_AML_Checking_Export_page(String yearmonthday) throws Throwable {
	    General.sendKeys(driver, By.name("CheckDate"), yearmonthday);
	    Thread.sleep(3000);
	}
	
	@When("^Double click the select box of CheckScope at AML Check of AML Checking Export page$")
	public void double_click_the_select_box_of_CheckScope_at_AML_Check_of_AML_Checking_Export_page() throws Throwable {
	    Actions action= new Actions(driver);
	    action.moveToElement(driver.findElement(By.name("CheckScope")));
	    action.doubleClick(driver.findElement(By.name("CheckScope"))).perform();
	    Thread.sleep(3000);
	}
	
	@When("^Select the \"([^\"]*)\" scope at AML Check of AML Checking Export page$")
	public void select_the_scope_at_AML_Check_of_AML_Checking_Export_page(String checkscope) throws Throwable {
		
		Select select = new Select(driver.findElement(By.name("codeselect")));
	    select.selectByVisibleText(checkscope);
	    Thread.sleep(3000);
	   
	}
	
	@When("^Click the button of AML Check at AML Check of AML Checking Export page$")
	public void click_the_button_of_AML_Check_at_AML_Check_of_AML_Checking_Export_page() throws Throwable {
		
		General.executeScript(driver, "arguments[0].click();", By.xpath("//*[@value='AMLCheck']")); 
		// System.out.println("Alert1:"+General.isAlertPresent(driver));
		    Thread.sleep(150000);	
		    driver.switchTo().alert();	    
		    Robot robot=new Robot();
		    robot.keyPress(KeyEvent.VK_ENTER);
		    Thread.sleep(3000);
		 //   General.isPresentCloseAlert(driver, true);
		    System.out.println("Alert:"+General.isAlertPresent(driver));
		    Thread.sleep(30000);
	}
	
	@Then("^The AML Check data show the current page and the Entity Type with \"([^\"]*)\"$")
	public void the_AML_Check_data_show_the_current_page_and_the_Entity_Type_with(String entitytype) throws Throwable {

		List<WebElement> element = driver.findElements(By.name("CheckResultGrid2"));
		// System.out.println(element.size());
		boolean result = false;
		for (int i = 0; i < element.size(); i++) {
			String text = element.get(i).getAttribute("value");
			Thread.sleep(3000);
			boolean tempresult = text.equals(entitytype);
			Thread.sleep(3000);
			if (tempresult) {
				result = tempresult;
				continue;
			} else {
				break;
			}
		}
		if (result)
			System.out.println("Verify successfully.");
		else
			throw new Exception("Verify failed.");
	
			
		}
	
	/*
	 * DIP_027_RSF82_AMLCheckingExportpage_ChecktheAMLCheckfounctionwithIndividualscope.feature
     @RFS-30
Feature: DIP-Automation-Story

	#step1: Login the DIP system
	#step2: Unfold the DIP
	#step3: Unfold the Export
	#step4: Click the Icon of AML Checking Export
	#step5: Select the value of YearMonthDay
	#step6: Double click the select box of CheckScope
	#step7: Select the Individual scope
	#step8: Click the button of AML Check
	#expected result: The AML Check data show the current page and the Entity Type with Individual
	@RFS-82
	Scenario Outline: DIP-AutoTC-AML Checking Export page-Check the AML Check founction with Individual scope
		Given Login the DIP system
		When Unfold the DIP
		And Unfold the Export
		And Click the Icon of AML Checking Export
		And Select the value of YearMonthDay "<yearmonthday>" at AML Check of AML Checking Export page
		And Double click the select box of CheckScope at AML Check of AML Checking Export page
		And Select the "<checkscope>" scope at AML Check of AML Checking Export page
		And Click the button of AML Check at AML Check of AML Checking Export page
		Then The AML Check data show the current page and the Entity Type with "<entitytype>"
		
	Examples:
     |yearmonthday  |checkscope    |entitytype |
	 |2019-11-07    |ind-Individual|Individual | 
	 * */
	    
	
	/*
	DIP_028_RFS85_AMLCheckingExportPage_ChecktheSearchfunctionbyNSCCodeatCheckResultsofAMLCheckingExportPage.feature
@RFS-30
Feature: DIP-Automation-Story

	#step1: Login the DIP system
	#step2: Unfold the DIP
	#step3: Unfold the Export
	#step4: Click the Icon of AML Checking Export
	#step5: Select the value of YearMonthDay
	#step6: Double click the select box of CheckScope
	#step7: Select the Individual scope
	#step8: Input the NSC_Code
	#step8: Click the button of Search
	#expected result:The search data with the same NSC_Code as you inputted
	#
	@RFS-85
	Scenario Outline: DIP-AutoTC-AML Checking Export Page-Check the Search function by NSC Code at Check Results of AML Checking Export Page
		Given Login the DIP system
		When Unfold the DIP
		And Unfold the Export
		And Click the Icon of AML Checking Export
		And Select the value of YearMonthDay "<yearmonthday>" at Check Results of AML Checking Export page
		And Double click the select box of CheckScope at Check Results of AML Checking Export page
		And Select the "<checkscope>" scope at Check Results of AML Checking Export page
		And Input the NSC_Code "<nsc>" at Check Results of AML Checking Export page
		And Click the button of Search at Check Results of AML Checking Export page
		Then The search data with the same NSC_Code "<nsc>" as you inputted at Check Results of AML Checking Export page
		
	Examples:
       |yearmonthday  |checkscope    |nsc  |
	   |2019-11-18    |ind-Individual|35215|  
	 * */
	
	@When("^Select the value of YearMonthDay \"([^\"]*)\" at Check Results of AML Checking Export page$")
	public void select_the_value_of_YearMonthDay_at_Check_Results_of_AML_Checking_Export_page(String yearmonthday) throws Throwable {
	    
		General.sendKeys(driver, By.name("CheckDateR"), yearmonthday);
	    Thread.sleep(3000);
	}
	
	@When("^Double click the select box of CheckScope at Check Results of AML Checking Export page$")
	public void double_click_the_select_box_of_CheckScope_at_Check_Results_of_AML_Checking_Export_page() throws Throwable {
		
		 Actions action= new Actions(driver);
		    action.moveToElement(driver.findElement(By.name("CheckScope2")));
		    action.doubleClick(driver.findElement(By.name("CheckScope2"))).perform();
		    Thread.sleep(3000);
		   	
	}
	
	@When("^Select the \"([^\"]*)\" scope at Check Results of AML Checking Export page$")
	public void select_the_scope_at_Check_Results_of_AML_Checking_Export_page(String checkscope) throws Throwable {
		Select select = new Select(driver.findElement(By.name("codeselect")));
	    select.selectByVisibleText(checkscope);
	    Thread.sleep(3000);    
	}
	
	@When("^Input the NSC_Code \"([^\"]*)\" at Check Results of AML Checking Export page$")
	public void input_the_NSC_Code_at_Check_Results_of_AML_Checking_Export_page(String nsc) throws Throwable {
		
		General.sendKeys(driver, By.name("NSC_Code"), nsc);
	    Thread.sleep(3000);
	    
	}
	
	@When("^Click the button of Search at Check Results of AML Checking Export page$")
	public void click_the_button_of_Search_at_Check_Results_of_AML_Checking_Export_page() throws Throwable {
		
		General.executeScript(driver, "arguments[0].click();", By.xpath("//*[@value='Search']")); 
		Thread.sleep(3000);
	    
	}
	
	@Then("^The search data with the same NSC_Code \"([^\"]*)\" as you inputted at Check Results of AML Checking Export page$")
	public void the_search_data_with_the_same_NSC_Code_as_you_inputted_at_Check_Results_of_AML_Checking_Export_page(String nsc) throws Throwable {
	  
		
		List<WebElement> element = driver.findElements(By.name("QueryResultGrid4"));
		// System.out.println(element.size());
		boolean result = false;
		for (int i = 0; i < element.size(); i++) {
			String text = element.get(i).getAttribute("value");
			Thread.sleep(3000);
			boolean tempresult = text.equals(nsc);
			Thread.sleep(3000);
			if (tempresult) {
				result = tempresult;
				continue;
			} else {
				break;
			}
		}
		if(result)
			System.out.println("Verify successfully.");
		else
			throw new Exception("Verify failed.");
	
	}
	/*
	 * DIP_0029_RFS84_AMLCheckingExportPage_ChecktheAMLCheckfunctionwithAllscope.feature
@RFS-30
Feature: DIP-Automation-Story

	#step1: Login the DIP system
	#step2: Unfold the DIP
	#step3: Unfold the Export
	#step4: Click the Icon of AML Checking Export
	#step5: Select the value of YearMonthDay
	#step6: Double click the select box of CheckScope
	#step7: Select the All scope
	#step8: Click the button of AML Check
	#expected result: The AML Check data show the currrent page and the Entity Type with Individual and Corporate
	#
	@RFS-84
	Scenario Outline: DIP-AutoTC-AML Checking Export Page-Check the AML Check function with All scope
		Given Login the DIP system
		When Unfold the DIP
		And Unfold the Export
		And Click the Icon of AML Checking Export
		And Select the value of YearMonthDay "<yearmonthday>" at AML Check of AML Checking Export page
        And Double click the select box of CheckScope at AML Check of AML Checking Export page
		And Select the "<checkscope>" scope at AML Check of AML Checking Export page
		And Click the button of AML Check at AML Check of AML Checking Export page
		Then The AML Check data show the currrent page and the Entity Type with "<entitytype1>" or "<entitytype2>"
		
	Examples:
     |yearmonthday  |checkscope |entitytype1 |entitytype2|
	 |2019-11-18    |all-All    |Individual  |Corporate  |
	 * */
	
	@Then("^The AML Check data show the currrent page and the Entity Type with \"([^\"]*)\" or \"([^\"]*)\"$")
	public void the_AML_Check_data_show_the_currrent_page_and_the_Entity_Type_with_or(String entitytype1,
			String entitytype2) throws Throwable {

		List<WebElement> element = driver.findElements(By.name("CheckResultGrid2"));
		System.out.println(element.size());
		boolean result = false;

		for (int i = 0; i < element.size(); i++) {
			String text = element.get(i).getAttribute("value");
			Thread.sleep(3000);
			boolean tempresult = text.contains(entitytype1) || text.contains(entitytype2);
			if (tempresult) {
				result = tempresult;
				continue;
			} else {
				break;
			}
		}
		
		if(result)
			System.out.println("Verify successfully.");
		else
			throw new Exception("Verify failed.");
			
	}
	
	/*
	 @RFS-30
Feature: DIP-Automation-Story

	#step1: Login the DIP system
	#step2: Unfold the DIP
	#step3: Unfold the Export
	#step4: Click the Icon of AML Checking Export
	#step5: Select the value of YearMonthDay
	#step6: Double click the select box of CheckScope
	#step7: Select the Individual scope
	#step8: Double click the select box and select the value of HitFlag
	#step9: Click the button of Search
	#expected result:The search data with the same HitFlag as you inputted
	#
	@RFS-87
	Scenario Outline: DIP-AutoTC-AML Checking Export Page-Check the Search function by HitFlag at Check Results of AML Checking Export Page
		Given Login the DIP system
		When Unfold the DIP
		And Unfold the Export
		And Click the Icon of AML Checking Export
		And Select the value of YearMonthDay "<yearmonthday>" at Check Results of AML Checking Export page
		And Double click the select box of CheckScope at Check Results of AML Checking Export page
		And Select the "<checkscope>" scope at Check Results of AML Checking Export page
		And Double click the select box of HitFlag at Check Results of AML Checking Export page
		And select the value of HitFlag "<hitflag>"
		And Click the button of Search at Check Results of AML Checking Export page 
		Then The search data with the same HitFlag "<hitflag>" as you inputted		
		Examples:
       |yearmonthday  |checkscope    |hitflag |
	   |2013-04-08    |ind-Individual|No      | 
	 * */
	
	/*
	    Given Login the DIP system
		When Unfold the DIP
		And Unfold the Export
		And Click the Icon of AML Checking Export
		And Select the value of YearMonthDay "<yearmonthday>" at Check Results of AML Checking Export page
		And Double click the select box of CheckScope at Check Results of AML Checking Export page
		And Select the "<checkscope>" scope at Check Results of AML Checking Export page 
	 * */
	@When("^Double click the select box of HitFlag at Check Results of AML Checking Export page$")
	public void double_click_the_select_box_of_HitFlag_at_Check_Results_of_AML_Checking_Export_page() throws Throwable {
		
		    Actions action= new Actions(driver);
		    action.moveToElement(driver.findElement(By.name("SuccessFlag")));
		    action.doubleClick(driver.findElement(By.name("SuccessFlag"))).perform();
		    Thread.sleep(3000);
	   
	}
	
	@When("^select the value of HitFlag \"([^\"]*)\"$")
	public void select_the_value_of_HitFlag(String hitflag) throws Throwable {
	    Select select =new Select(driver.findElement(By.name("codeselect")));    
	    select.selectByValue(hitflag);
	    Thread.sleep(3000);
	}
	
	//And Click the button of Search at Check Results of AML Checking Export page
	
	@Then("^The search data with the same HitFlag \"([^\"]*)\" as you inputted$")
	public void the_search_data_with_the_same_HitFlag_as_you_inputted(String hitfalg) throws Throwable {
		List<WebElement> element = driver.findElements(By.name("QueryResultGrid11"));
		System.out.println(element.size());
		boolean result = false;

		for (int i = 0; i < element.size(); i++) {
			String text = element.get(i).getAttribute("value");
			Thread.sleep(3000);
			boolean tempresult = text.equals(hitfalg);
			if (tempresult) {
				result = tempresult;
				continue;
			} else {
				break;
			}
		}
		
		if(result)
			System.out.println("Verify successfully.");
		else
			throw new Exception("Verify failed.");
	    
	}
	
	/*
	@RFS-30
Feature: DIP-Automation-Story

	#step1: Login the DIP system
	#step2: Unfold the DIP
	#step3: Unfold the Export
	#step4: Click the Icon of AML Checking Export
	#step5: Select the value of YearMonthDay
	#step6: Double click the select box of CheckScope
	#step7: Select the Individual scope
	#step8: Input the Dealer Name
	#step8: Click the button of Search
	#expected result:The search data with the same Dealer Name as you inputted
	#
	@RFS-86
	Scenario Outline: DIP-AutoTC-AML Checking Export Page-Check the Search function by DealerName at Check Results of AML Checking Export Page
		Given Login the DIP system
		When Unfold the DIP
		And Unfold the Export
		And Click the Icon of AML Checking Export
		And Select the value of YearMonthDay "<yearmonthday>" at Check Results of AML Checking Export page
		And Double click the select box of CheckScope at Check Results of AML Checking Export page
		And Select the "<checkscope>" scope at Check Results of AML Checking Export page
		And Input the Dealer Name "<dealername>" at Check Results of AML Checking Export page
		And Click the button of Search at Check Results of AML Checking Export page
		Then The search data with the same Dealer Name "<dealername>" as you inputted at Check Results of AML Checking Export page
		
		
	Examples:
         |yearmonthday  |checkscope    |dealername                                         |
	     |2013-04-08    |ind-Individual|Yongjia Baozen Automotive Sales & Service Co., Ltd.| 
	 * */
	
	/*
	 	Given Login the DIP system
		When Unfold the DIP
		And Unfold the Export
		And Click the Icon of AML Checking Export
		And Select the value of YearMonthDay "<yearmonthday>" at Check Results of AML Checking Export page
		And Double click the select box of CheckScope at Check Results of AML Checking Export page
		And Select the "<checkscope>" scope at Check Results of AML Checking Export page
	 * */
	
	@When("^Input the Dealer Name \"([^\"]*)\" at Check Results of AML Checking Export page$")
	public void input_the_Dealer_Name_at_Check_Results_of_AML_Checking_Export_page(String dealername) throws Throwable {
		
	    General.sendKeys(driver, By.name("DealerNameEn"), dealername);
	    Thread.sleep(3000);
	}
	
	//And Click the button of Search at Check Results of AML Checking Export page
	
	@Then("^The search data with the same Dealer Name \"([^\"]*)\" as you inputted at Check Results of AML Checking Export page$")
	public void the_search_data_with_the_same_Dealer_Name_as_you_inputted_at_Check_Results_of_AML_Checking_Export_page(String dealername) throws Throwable {
	    
	
		List<WebElement> element = driver.findElements(By.name("QueryResultGrid5"));
		System.out.println(element.size());
		boolean result = false;

		for (int i = 0; i < element.size(); i++) {
			String text = element.get(i).getAttribute("value");
			Thread.sleep(3000);
			boolean tempresult = text.contains(dealername);
			if (tempresult) {
				result = tempresult;
				continue;
			} else {
				break;
			}
		}
		
		if(result)
			System.out.println("Verify successfully.");
		else
			throw new Exception("Verify failed.");
	
	}
	
	/*
	 * IP_035_RFS89_AMLCheckingExportPage_ChecktheExportfunctionwiththeconditionofNSCCodeatCheckResultsofAMLCheckingExportPage.feature
	@RFS-30
Feature: DIP-Automation-Story

	#step1: Login the DIP system
	#step2: Unfold the DIP
	#step3: Unfold the Export
	#step4: Click the Icon of AML Checking Export
	#step5: Select the value of YearMonthDay
	#step6: Double click the select box of CheckScope
	#step7: Select the Individual scope
	#step8: Input the NSC_Code
	#step9: Click the button of Search
	#expected result:The search data with the same NSC_Code as you inputted
	#step10: Click the button of Export
	#Step11: Click the button of Open at the Pop_up box
	#expected result: Check the NSC_Code is same as your searched
	#
	@RFS-89
	Scenario Outline: DIP-AutoTC-AML Checking Export Page-Check the Export function with the condition of NSC_Code at Check Results of AML Checking Export Page
		Given Login the DIP system
		When Unfold the DIP
		And Unfold the Export
		And Click the Icon of AML Checking Export
		And Select the value of YearMonthDay "<yearmonthday>" at Check Results of AML Checking Export page
		And Double click the select box of CheckScope at Check Results of AML Checking Export page
		And Select the "<checkscope>" scope at Check Results of AML Checking Export page
		And Input the NSC_Code "<nsc>" at Check Results of AML Checking Export page
		And Click the button of Search at Check Results of AML Checking Export page
		Then The search data with the same NSC_Code "<nsc>" as you inputted
		When Click the button of Export at Check Results of AML Checking Export page
		And Click the button of Save as "<importtemplatedownload>"at the Pop_up box
		Then Check the NSC_Code "<nsc>" is same as your searched
			
		Examples:
       |yearmonthday  |checkscope    |nsc  |importtemplatedownload|
	   |2013-04-08    |ind-Individual|35215|AMLCheckExportWithNSC | 
	 * */
	
	/*
	 @RFS-30
Feature: DIP-Automation-Story

	#step1: Login the DIP system
	#step2: Unfold the DIP
	#step3: Unfold the Export
	#step4: Click the Icon of AML Checking Export
	#step5: Select the value of YearMonthDay
	#step6: Double click the select box of CheckScope
	#step7: Select the Individual scope
	#step8: Input the NSC_Code
	#step9: Click the button of Search
	#expected result:The search data with the same NSC_Code as you inputted
	#step10: Click the button of Export
	#Step11: Click the button of Open at the Pop_up box
	#expected result: Check the NSC_Code is same as your searched
	#
	@RFS-89
	Scenario Outline: DIP-AutoTC-AML Checking Export Page-Check the Export function with the condition of NSC_Code at Check Results of AML Checking Export Page
		Given Login the DIP system
		When Unfold the DIP
		And Unfold the Export
		And Click the Icon of AML Checking Export
		And Select the value of YearMonthDay "<yearmonthday>" at Check Results of AML Checking Export page
		And Double click the select box of CheckScope at Check Results of AML Checking Export page
		And Select the "<checkscope>" scope at Check Results of AML Checking Export page
		And Input the NSC_Code "<nsc>" at Check Results of AML Checking Export page
		And Click the button of Search at Check Results of AML Checking Export page
		Then The search data with the same NSC_Code "<nsc>" as you inputted
		When Click the button of Export at Check Results of AML Checking Export page
		And Click the button of Save as "<importtemplatedownload>"at the Pop_up box
		Then Check the NSC_Code "<nsc>" is same as your searched
				
		Examples:
       |yearmonthday  |checkscope    |nsc  |importtemplatedownload|
	   |2013-04-08    |ind-Individual|35215|AMLCheckExportWithNSC |
	 * */
	
	/*
	 	Given Login the DIP system
		When Unfold the DIP
		And Unfold the Export
		And Click the Icon of AML Checking Export
		And Select the value of YearMonthDay "<yearmonthday>" at Check Results of AML Checking Export page
		And Double click the select box of CheckScope at Check Results of AML Checking Export page
		And Select the "<checkscope>" scope at Check Results of AML Checking Export page
		And Input the NSC_Code "<nsc>" at Check Results of AML Checking Export page
		And Click the button of Search at Check Results of AML Checking Export page 
		Then The search data with the same NSC_Code "<nsc>" as you inputted at Check Results of AML Checking Export page
	 * */
		
	@When("^Click the button of Export at Check Results of AML Checking Export page$")
	public void click_the_button_of_Export_at_Check_Results_of_AML_Checking_Export_page() throws Throwable {
		
	   General.executeScript(driver, "arguments[0].click();", By.xpath("//*[@value='Export']"));    
	   Thread.sleep(3000);
	}
	
	@Then("^Check the NSC_Code \"([^\"]*)\" is same as your export excel$")
	public void check_the_NSC_Code_is_same_as_your_export_excel(String arg1) throws Throwable {
	    
	}
	
	}
	


