package stepDefinitionsForDIP;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import General.General;
import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class CheckDailyImportPortfolioPage {
	WebDriver driver=Hook.getDriver();
	
	/*
	 * DIP_030_RFS43_DailyImportPortfolioPage_ChecktheImportfilefunction.feature
	@RFS-30
Feature: DIP-Automation-Story

	#step1: Logged in the DIP system
	#step2: Unfold the "DIP"
	#step3: Unfold the "Regular Import"
	#step4: Unfold the "Outstanding Portfolio"
	#step5: Click the Icon of "Daily Import-Portfolio"
	#step6: Select  the value of "Year Month"
	#step7: Click the button of "Browser" to select your file that you want to import
	#step8: Click the button of "Import"
	#step9: Click the button of "Ok" at the Pop_up box
	#expected result: We can see one file was named "DailyImportPortfolio.xlsx" in the "Reminder Information"
	@RFS-43
	Scenario Outline: DIP-AutoTC-Daily Import-Portfolio Page-Check the Import file function
		Given Login the DIP system
		And Unfold the DIP
		And Unfold the Regular Import
		And Unfold the Outstanding Portfolio
		And Click the Icon of Daily Import-Portfolio
		And Select  the value of Year Month at Daily Import-Portfolio Page
		And Click the button of Browser at Daily Import-Portfolio Page
        And select your file that you want to import "<ImportReport>"
		When Click the button of Import at Daily Import-Portfolio Page
		And Click the button of Ok at the Pop_up box
		Then We can see one file was named "<ImportReport>" in the Reminder Information at Daily Import-Portfolio Page
		
		Examples:
       |yearmonth  |ImportReport              |
	   |2019-09    |DailyImportPortfolio.xlsx | 
	 * */
	
	
	@Given("^Click the Icon of Daily Import-Portfolio$")
	public void click_the_Icon_of_Daily_Import_Portfolio() throws Throwable {
	    General.executeScript(driver, "arguments[0].click();", By.linkText("Daily Import-Portfolio"));
	    Thread.sleep(3000);
	    driver.switchTo().defaultContent();
	    driver.switchTo().frame("fraInterface");
	    Thread.sleep(3000);
	}
	
	@Given("^Select  the value of YearMonth \"([^\"]*)\" at Daily Import-Portfolio Page$")
	public void select_the_value_of_YearMonth_at_Daily_Import_Portfolio_Page(String yearmonth) throws Throwable {
		General.sendKeys(driver, By.name("YearMonth"), yearmonth);
		Thread.sleep(3000);
	    
	}
	
	@Given("^Click the button of Browser at Daily Import-Portfolio Page$")
	public void click_the_button_of_Browser_at_Daily_Import_Portfolio_Page() throws Throwable {
		WebElement browseBtn=driver.findElement(By.name("FileName"));
		  Actions action =new Actions(driver);
		  action.moveToElement(browseBtn);
		  action.doubleClick(browseBtn).perform();
			Thread.sleep(3000);
	}
	//And select your file that you want to import "<ImportReport>"
	
	@When("^Click the button of Import at Daily Import-Portfolio Page$")
	public void click_the_button_of_Import_at_Daily_Import_Portfolio_Page() throws Throwable {
		
		  General.executeScript(driver, "arguments[0].click();", By.xpath("//*[@value='Import']"));
		    Thread.sleep(3000);
	    
	}
	//And Click the button of Ok at the Pop_up box
	
	@Then("^We can see one file was named \"([^\"]*)\" in the Reminder Information at Daily Import-Portfolio Page$")
	public void we_can_see_one_file_was_named_in_the_Reminder_Information_at_Daily_Import_Portfolio_Page(String ImportReport) throws Throwable {
		   //click last page button	
		  By lastPageBtn = By.xpath("//img[@name='btnchangepage' and @src='https://dip-test.bmwgroup.net/dip-test/common/images/lastPage.gif']");
		  WebElement clickLastPageBtn = driver.findElement(lastPageBtn);
		  JavascriptExecutor js = (JavascriptExecutor) driver;
		  js.executeScript("arguments[0].click();", clickLastPageBtn);
		  General.isPresentCloseAlert(driver, true);// if there is only one page
		  Thread.sleep(5000);
		 

		By tableField = By.xpath("(//*[@name='ImportInfoGrid2'])[last()]"); //@class='mulreadonly' and 
		String lineOneData = driver.findElement(tableField).getAttribute("value");
		
		if (lineOneData != "") {
			if (lineOneData.indexOf(ImportReport) != -1) {
				System.out.println("Verify Import Report successfully.");
			} else {
				throw new Exception("Verify Import Report failed.");
			}
		} else {
			throw new Exception("Import Import Report failed.");
		}
	}
	
	
	
}
