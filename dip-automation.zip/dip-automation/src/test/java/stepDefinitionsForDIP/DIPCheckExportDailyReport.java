package stepDefinitionsForDIP;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;

public class DIPCheckExportDailyReport {
	
	WebDriver driver=Hook.getDriver();
	
	@Given("^Click the Icon of Daily Report Portfolio \"([^\"]*)\"$")
	public void click_the_Icon_of_Daily_Report_Portfolio(String dailyReportPortfolio) throws Throwable {
		if (General.General.JudgingElementByContainsText(driver, dailyReportPortfolio))
		{
			String dailyReportPortfolioId = driver.findElement(By.xpath("//a[contains(text(),\'" + dailyReportPortfolio + "\')]")).getAttribute("id");
			System.out.println("Daily Report Portfolio Id:" + dailyReportPortfolioId);
			driver.findElement(By.id(dailyReportPortfolioId)).sendKeys(Keys.ENTER);
		}
		Thread.sleep(5000);
		driver.switchTo().defaultContent();
		
		driver.switchTo().frame("fraInterface");
	}

	@Given("^Select the value of Year-Month-Day\"([^\"]*)\"$")
	public void select_the_value_of_Year_Month_Day(String date) throws Throwable {
		By reportingDateId=By.id("reportingDate");
		General.General.waitUntilvisiable(driver, 20, reportingDateId);
		driver.findElement(reportingDateId).sendKeys(date);
		Thread.sleep(3000);
	}
	
	@When("^Click the \\[Export Excel\\] button$")
	public void click_the_Export_Excel_button() throws Throwable {
		By exportByClass=By.className("cssButton");
	    driver.findElement(exportByClass).click();
	    Thread.sleep(2000);
	}

}
