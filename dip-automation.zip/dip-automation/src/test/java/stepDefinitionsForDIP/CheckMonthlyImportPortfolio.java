package stepDefinitionsForDIP;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.IOException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import General.General;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class CheckMonthlyImportPortfolio {
	
	WebDriver driver=Hook.getDriver();
	/*
	 *  DIP_025_RFS49_MonthlyImportPortfoliopage_ChecktheImportfilefunction.feature
@RFS-30
Feature: DIP-Automation-Story

	#step1: Logged in the DIP system
	#step2: Unfold the "DIP"
	#step3: Unfold the "Regular Import"
	#step4: Unfold the "Outstanding Portfolio"
	#step5: Click the Icon of "Monthly Import-Portfolio"
	#step6: Select the value of "Year Month"
	#step7: Click the button of "Browser" to select your file that you want to import
	#step8: Click the button of "Import"
	#step9: Click the button of "Ok" at the Pop_up box
	#expected result: We can see one file was named "ImportMonthlyReport.xlsx" in the "Reminder Information"
	@RFS-49
	Scenario: DIP-AutoTC-Monthly Import-Portfolio page-Check the Import file function
		Given Login the DIP system
		And Unfold the DIP
		And Unfold the Regular Import
		And Unfold the Outstanding Portfolio
		And Click the Icon of Monthly Import-Portfolio
		And Select  the value of Year Month "<yearmonth>" at Monthly Import-Portfolio Page 
		And Click the button of Browser and select your file that you want to import at Monthly Import-Portfolio Page
		When Click the button of Import at Monthly Import-Portfolio Page
		And Click the button of Ok at the Pop_up box
		Then We can see one file was named "<ImportReport>" in the Reminder Information
		
		Examples:
     |yearmonth  |ImportReport                      |
	 |2019-09    |ImportMonthlyProtfolioReport.xlsx |
	 * */
	@Given("^Unfold the Outstanding Portfolio$")
	public void unfold_the_Outstanding_Portfolio() throws Throwable {
		General.executeScript(driver, "arguments[0].click();", By.linkText("Outstanding Portfolio"));
		Thread.sleep(3000);
		
	}
	
	@Given("^Click the Icon of Monthly Import-Portfolio$")
	public void click_the_Icon_of_Monthly_Import_Portfolio() throws Throwable {
		   General.executeScript(driver, "arguments[0].click();", By.linkText("Monthly Import-Portfolio"));
		   Thread.sleep(3000);
		   driver.switchTo().defaultContent();
		   driver.switchTo().frame("fraInterface");
		   Thread.sleep(3000);	    
	}
	
	@Given("^Select  the value of Year Month \"([^\"]*)\" at Monthly Import-Portfolio Page$")
	public void select_the_value_of_Year_Month_at_Monthly_Import_Portfolio_Page(String yearmonth) throws Throwable {
	    General.sendKeys(driver, By.name("YearMonth"), yearmonth);
	    Thread.sleep(3000);	
	}
	
	@Given("^Click the button of Browser at Monthly Import-Portfolio Page$")
	public void click_the_button_of_Browser_at_Monthly_Import_Portfolio_Page() throws Throwable {
		
		WebElement browseBtn=driver.findElement(By.name("FileName"));
		  Actions action =new Actions(driver);
		  action.moveToElement(browseBtn);
		  action.doubleClick(browseBtn).perform();
			Thread.sleep(3000);
	}
	@Given("^select your file that you want to import \"([^\"]*)\"$")
	public void select_your_file_that_you_want_to_import(String ImportReport) throws Throwable {
		
		Runtime uploadexe = Runtime.getRuntime();
		try {
			Thread.sleep(5000);
			uploadexe.exec(Hook.getUploadTool()+" "+Hook.getUploadPath() + ImportReport);  //Upload file
			Thread.sleep(10000);
		} catch (IOException e) {
			e.printStackTrace();
		}
		Thread.sleep(5000);
	}
	
	@When("^Click the button of Import at Monthly Import-Portfolio Page$")
	public void click_the_button_of_Import_at_Monthly_Import_Portfolio_Page() throws Throwable {
		
		General.executeScript(driver, "arguments[0].click();", By.xpath("//*[@value='Import']"));
		Thread.sleep(3000);
	    
	}
	
	@When("^Click the button of Ok at the Pop_up box$")
	public void click_the_button_of_Ok_at_the_Pop_up_box() throws Throwable {
		Thread.sleep(10000);
		driver.switchTo().alert().accept();; //Switch to Alert window
		
		Robot robot = new Robot();
		robot.keyPress(KeyEvent.VK_ENTER);  // Click "OK" button
		Thread.sleep(5000);
	    
	}
	
	@Then("^We can see one file was named \"([^\"]*)\" in the Reminder Information at Monthly Import-Portfolio Page$")
	public void we_can_see_one_file_was_named_in_the_Reminder_Information_at_Monthly_Import_Portfolio_Page(String ImportReport) throws Throwable {
	    
	   //click last page button	
		  By lastPageBtn = By.xpath("//img[@name='btnchangepage' and @src='https://dip-test.bmwgroup.net/dip-test/common/images/lastPage.gif']");
		  WebElement clickLastPageBtn = driver.findElement(lastPageBtn);
		  JavascriptExecutor js = (JavascriptExecutor) driver;
		  js.executeScript("arguments[0].click();", clickLastPageBtn);
		  General.isPresentCloseAlert(driver, true);// if there is only one page
		  Thread.sleep(5000);
		 

		By tableField = By.xpath("(//*[@name='ImportInfoGrid2'])[last()]"); //@class='mulreadonly' and 
		String lineOneData = driver.findElement(tableField).getAttribute("value");
		
		if (lineOneData != "") {
			if (lineOneData.indexOf(ImportReport) != -1) {
				System.out.println("Verify Import Report successfully.");
			} else {
				throw new Exception("Verify Import Report failed.");
			}
		} else {
			throw new Exception("Import Import Report failed.");
		}
	
	}


}
