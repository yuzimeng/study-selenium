package stepDefinitionsForDIP;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import DIPPage.DIPDealerManagermentPage;
import General.General;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;
import junit.framework.Assert;

public class DIPDealerManagementpage {

	WebDriver driver = Hook.getDriver();

	DIPDealerManagermentPage dmp = new DIPDealerManagermentPage(driver);
	/*
	 * DIP_008_DealerManagementpage-CheckUpdatedealerstatus Given Login the DIP
	 * system And Unfold the DIP
	 */

	@Given("^Unfold the Dealer Management$")
	public void unfold_the_Dealer_Management() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		dmp.UnfoltheDealerManagement();
		Thread.sleep(10000);
	}

	@Given("^Click the Icon Dealer Management$")
	public void click_the_Icon_Dealer_Management() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		dmp.clicktheIconDealerManagement();
		Thread.sleep(10000);
	}

	@Given("^Input the NSC Code \"([^\"]*)\"$")
	public void input_the_NSC_Code(String nsc) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		dmp.inputtheNSCCode(nsc);
		Thread.sleep(10000);
	}

	@Given("^Click the button of Search in the Dealer Management page$")
	public void click_the_button_of_Search_in_the_Dealer_Management_page() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		dmp.clickthebuttonofSearchintheDealerManagementpage();
		Thread.sleep(10000);
	}

	@Given("^Double click the value of System Code$")
	public void double_click_the_value_of_System_Code() throws Throwable {

		// Write code here that turns the phrase above into concrete actions
       dmp.doubleclickthevalueofSystemCode();
		Thread.sleep(10000);
	}

	@When("^Click the button of OK at the Pop_up box$")
	public void click_the_button_of_OK_at_the_Pop_up_box() throws Throwable {
		// Write code here that turns the phrase above into concrete actions		
	    dmp.clickthebuttonofOKatthePopupbox();
	    Thread.sleep(1000);
	}

	@Given("^Change the status$")
	public void change_the_status() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		dmp.changethestatus();
		
	}
	
	@Given("^Click the button of Confirm$")
	public void click_the_button_of_Confirm() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		dmp.clickthebuttonofConfirm();
		Thread.sleep(1000);
	}
	
	
	@Given("^Show the pop up and click OK$")
	public void show_the_pop_up_and_click_OK() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   dmp.showthepopupandclickOK();
	   Thread.sleep(1000);
	}
	
	@Given("^Back to the Dealer Management page$")
	public void back_to_the_Dealer_Management_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		 driver.close();
		 Thread.sleep(1000);
		// driver.switchTo().defaultContent();
	}
	
	@Given("^Check the dealer status already changed$")
	public void check_the_dealer_status_already_changed() throws Throwable {
		//General.switchToFrame(driver, By.name("fraInterface"));
         dmp.clickthebuttonofSearchintheDealerManagementpage();	
		Thread.sleep(1000);	
		String text = General.getAttribute(driver, By.id("PolGrid15r1"), "value");
		String value=dmp.showthepopupandclickOK();
		Assert.assertEquals(value, text);
	    
	}
	
	
	
}
