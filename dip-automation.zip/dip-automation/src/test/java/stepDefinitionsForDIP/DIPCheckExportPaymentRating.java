package stepDefinitionsForDIP;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;

public class DIPCheckExportPaymentRating {
	
	WebDriver driver=Hook.getDriver();
	
	@Given("^Click the Icon of Payment Rating \"([^\"]*)\"$")
	public void click_the_Icon_of_Payment_Rating(String paymentRating) throws Throwable {
		if (General.General.JudgingElementByContainsText(driver, paymentRating))
		{
			String paymentRatingId = driver.findElement(By.xpath("//a[contains(text(),\'" + paymentRating + "\')]")).getAttribute("id");
			System.out.println("Daily Report Portfolio Id:" + paymentRatingId);
			driver.findElement(By.id(paymentRatingId)).sendKeys(Keys.ENTER);
		}
		Thread.sleep(5000);
		driver.switchTo().defaultContent();
		
		driver.switchTo().frame("fraInterface");
	}

	@Given("^Click the button of Calculation$")
	public void click_the_button_of_Calculation() throws Throwable {
		By importTemplateDownload = By.xpath("//input[@class='cssButton' and @value='Calculation']");
		WebElement selectOption = driver.findElement(importTemplateDownload);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].click();", selectOption);
		Thread.sleep(3000);
		
		boolean acceptNextAlert=true;
		General.General.closeAlertAndGetItsText(driver, acceptNextAlert);
		Thread.sleep(8000);
		
	}
	
	@When("^Click the \\[Export\\] button of Payment Rating$")
	public void click_the_Export_button_of_Payment_Rating() throws Throwable {
		By exportBtnOfSearchCondition1 = By.xpath("//input[@class='cssButton' and @onclick='Export()']");
		WebElement selectOption = driver.findElement(exportBtnOfSearchCondition1);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].click();", selectOption);
		Thread.sleep(3000);
	}

}
