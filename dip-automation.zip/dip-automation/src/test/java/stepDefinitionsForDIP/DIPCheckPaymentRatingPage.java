package stepDefinitionsForDIP;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import DIPPage.DIPLogin;
import DIPPage.DIPPaymentRatingPage;
import General.General;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import junit.framework.Assert;

public class DIPCheckPaymentRatingPage {
	
	/*
	 * DIP_003_ChecktheSearchfounctionbytheNSCCode  @RFS-57
	 * DIP_004_ChecktheSearchfounctionbytheDealerShortName.feature 	@RFS-58
	 * DIP_005_PaymentRatingPage_ChecktheSearchfounctionbyRating.feature 	@RFS-59
	 * DIP_007_PaymentRating_Checkthecalculationfounction.feature @RFS-56
	 * DIP_009_PaymentRatingPage_Checkthe5~7PointsExportfounction.feature Given  @RFS-60
	 * /

	/*
	 * DIP_003_ChecktheSearchfounctionbytheNSCCode  @RFS-57
	 * 
	 * 	Given Login the DIP system
	 *  Unfold the DIP
	 */	
	WebDriver driver=Hook.getDriver();
	DIPPaymentRatingPage prp =new DIPPaymentRatingPage(driver);
	
	@When("^Unfold the Export$")
	public void unfold_the_Export() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    prp.unfoldtheExport();
	    Thread.sleep(1000);
	}
	
	@When("^Click the Icon of Payment Rating$")
	public void click_the_Icon_of_Payment_Rating() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
      prp.clicktheIconofPaymentRating();
      Thread.sleep(1000);
	}
	
	@When("^Select the value of Year Month \"([^\"]*)\"$")
	public void select_the_value_of_Year_Month(String yearmonth) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
         prp.selectthevalueofYearMonth(yearmonth);
         Thread.sleep(1000);
	}
	
	@When("^Input the NSC Cod \"([^\"]*)\"$")
	public void input_the_NSC_Cod(String nsc) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
       prp.inputtheNSCCod(nsc);
       Thread.sleep(1000);
	}
	
	@When("^Click the button of Search$")
	public void click_the_button_of_Search() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions 
		prp.clickthebuttonofSearch();
		 Thread.sleep(1000);
	}
	
	@Then("^We can find the data \"([^\"]*)\"that you searched in the Search Results$")
	public void we_can_find_the_data_that_you_searched_in_the_Search_Results(String nsc) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		List<WebElement> elements=driver.findElements(By.name("CaseGrid1"));
		
		for (WebElement element: elements) {
			
			Assert.assertEquals(nsc, element.getAttribute("value"));
			
			
		}
	}
	
	/*
	 * DIP_004_ChecktheSearchfounctionbytheDealerShortName.feature 	@RFS-58
	 * 
	 * Given Login the DIP system
		When Unfold the DIP
		And Unfold the Export
		And Click the Icon of Payment Rating
		And Select the value of Year Month "<yearmonth>" 
	 */
	
	@When("^Input the Dealer ShortName \"([^\"]*)\"$")
	public void input_the_Dealer_ShortName(String dealershortname) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		prp.inputtheDealerShortName(dealershortname);
		 Thread.sleep(1000);
	}
	
	//And Click the button of Search
	
	@Then("^We can find the dealeshorname \"([^\"]*)\"that you searched in the Search Results$")
	public void we_can_find_the_dealeshorname_that_you_searched_in_the_Search_Results(String dealeshorname) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    
	List<WebElement> elements=driver.findElements(By.name("CaseGrid2"));
		
		for (WebElement element: elements) {
			
			Assert.assertEquals(dealeshorname, element.getAttribute("value"));
			
			
		}
	}
	
	/*
	 * DIP_005_PaymentRatingPage_ChecktheSearchfounctionbyRating.feature 	@RFS-59
	 * 
	 * Given Login the DIP system
		When Unfold the DIP
		And Unfold the Export
		And Click the Icon of Payment Rating
		And Select the value of Year Month "<yearmonth>" 
	 */

	@When("^Double click the Rating text box and select one kinds of rating \"([^\"]*)\"$")
	public void double_click_the_Rating_text_box_and_select_one_kinds_of_rating(String rating) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
          prp.doubleclicktheRatingtextboxandselectonekindsofrating(rating);

		 Thread.sleep(1000);	   
	}
	
    //And Click the button of Search
	
	@Then("^We can find the data rating \"([^\"]*)\" that you searched in the Search Results$")
	public void we_can_find_the_data_rating_that_you_searched_in_the_Search_Results(String rating) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
      List<WebElement> elements=driver.findElements(By.name("CaseGrid9"));
		
		for (WebElement element: elements) {
			
			Assert.assertEquals(rating, element.getAttribute("value"));
					
		}
			
	}
	/*
	 * DIP_007_PaymentRating_Checkthecalculationfounction.feature @RFS-56 Given
	 * Login the DIP system When Unfold the DIP And Unfold the Export And Click the
	 * Icon of Payment Rating And Select the value of Year Month "<yearmonth>"
	 */
	
	/*
	 * @When("^Click the button of Calculation$") public void
	 * click_the_button_of_Calculation() throws Throwable {
	 * 
	 * prp.clickthebuttonofCalculation(); Thread.sleep(1000);
	 * 
	 * 
	 * }
	 */
	
	@Then("^There are serval data in the Search Results$")
	public void there_are_serval_data_in_the_Search_Results() throws Throwable {
	   	
	   String	message	=prp.afterclickCalculation(driver);
		List<WebElement> elements=driver.findElements(By.name("CaseGrid1"));
		int lenth=elements.size();
		
		if(message.equals("No Result")) {
			Assert.assertEquals(0, lenth);
		}
		else {
			Assert.assertEquals(lenth!=0, lenth!=0);
			
		}
				
	}
	
	/*
	 * DIP_009_PaymentRatingPage_Checkthe5~7PointsExportfounction.feature Given  @RFS-60
	 * @RFS-30
Feature: DIP-Automation-Story

	#step1: Login the DIP system
	#step2: Unfold the DIP
	#step3: Unfold the Export
	#step4: Click the Icon of Payment Rating
	#step5: Select the value of Year Month "2019-09"
	#step6: Click the button of Calculation
	#step7: Click the button of 5-7 Points Export
	#step8: Click the button of Save as "ImpportStockAuditRating"at the Pop_up box
	#expected result: There is a Excel was downloaded
	@RFS-60
	Scenario Outline: DIP-AutoTC-Export page-Check the 5~7 Points Export founction
		Given Login the DIP system
		When Unfold the DIP
		And Unfold the Export
		And Click the Icon of Payment Rating
		And Select the value of Year Month "<yearmonth>"
		And Click the button of Calculation
		And Click the button of 5-7 Points Export
		And Click the button of Save as "<importtemplatedownload>"at the Pop_up box
		Then There is a Excel was downloaded
		
		Examples:
       |yearmonth||importtemplatedownload |
	   |2019-09  ||ImpportStockAuditRating|
	 */
	
	/*
	 * @Given("^Login the DIP system$") public void login_the_DIP_system() throws
	 * Throwable {
	 * actions DIPLogin login= new DIPLogin(driver); login.login();
	 * driver.switchTo().defaultContent(); Thread.sleep(10000); }
	 * 
	 * @When("^Unfold the DIP$") public void unfold_the_DIP() throws Throwable { 
	 * General.switchToFrame(driver, By.name("fraMenu")); sar.unfoldtheDIP();
	 * Thread.sleep(10000);
	 * 
	 * }
	 */
	
	
	
	
	
	
	@When("^Click the button of (\\d+)-(\\d+) Points Export$")
	public void click_the_button_of_Points_Export(int arg1, int arg2) throws Throwable {
		
	String	message=prp.afterclickCalculation(driver);
	Thread.sleep(10000);
	    // Write code here that turns the phrase above into concrete actions
	    prp.clickthebuttonofPointsExport();
	   Thread.sleep(10000);
	  String messagetext= prp.afterclickExport(driver);
	  
	  if(message.equals("No Result"))
	  {Assert.assertEquals("Search Resultsshould not be null", messagetext);}
	 
}
	/*
	 * And Click the button of Save as "<importtemplatedownload>"at the Pop_up box
	 * Then There is a Excel was downloaded
	 */	
	
	
	
	
	
}
