package stepDefinitionsForDIP;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

import DIPPage.DIPStockAuditReportagePage;
import General.General;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import junit.framework.Assert;

public class DIPCheckStockAuditReportagepage {
	/*
	 * DIP_010_StockAuditReportagepage_ChecktheExportfounction.feature @RFS-70
	 * DIP_011_StockAuditReportPage_ChecktheSearchbyNSCCodeandExportfounctionofDealerMangement
	 * .feature @RFS-72
	 * 
	 */

	/*
	 * DIP_010_StockAuditReportagepage_ChecktheExportfounction.feature @RFS-70 Given
	 * Login the DIP system When Unfold the DIP And Unfold the Export
	 */

	WebDriver driver = Hook.getDriver();
	DIPStockAuditReportagePage sar = new DIPStockAuditReportagePage(driver);

	@When("^Click the Icon of Stock Audit Report$")
	public void click_the_Icon_of_Stock_Audit_Report() throws Throwable {
		sar.clicktheIconofStockAuditReport();
		Thread.sleep(1000);

	}

	@When("^Select the value of Year Month\"([^\"]*)\" at Dealer Management of the at Stock Audit Report Page$")
	public void select_the_value_of_Year_Month_at_Dealer_Management_of_the_at_Stock_Audit_Report_Page(String yearmonth)
			throws Throwable {
		sar.selectthevalueofYearMonthatDealerManagementoftheatStockAuditReportPage(yearmonth);
		Thread.sleep(1000);
	}

	@When("^Click the button of Calculate at Dealer Management of the at Stock Audit Report Page$")
	public void click_the_button_of_Calculate_at_Dealer_Management_of_the_at_Stock_Audit_Report_Page()
			throws Throwable {

		General.executeScript(driver, "arguments[0].click();", By.xpath("//*[@value='Calculate']"));
		Thread.sleep(1000);
	}

	@Then("^There are several data in the Search Results at Dealer Management of the at Stock Audit Report Page$")
	public void there_are_several_data_in_the_Search_Results_at_Dealer_Management_of_the_at_Stock_Audit_Report_Page()
			throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		String message = General.isPresentGetAlertext(driver);
		General.isPresentCloseAlert(driver, true);
		Thread.sleep(10000);
		List<WebElement> elements = driver.findElements(By.name("CaseGridRating1"));
		int lenth = elements.size();

		if (message.equals("No Result")) {
			Assert.assertEquals(0, lenth);
		} else {
			Assert.assertEquals(lenth != 0, lenth != 0);

		}
		Thread.sleep(1000);
	}

	@When("^Click the button of Export at Dealer Management of the at Stock Audit Report Page$")
	public void click_the_button_of_Export_at_Dealer_Management_of_the_at_Stock_Audit_Report_Page() throws Throwable {

		 By exportBtnOfSearchCondition1 = By.xpath("//input[@class='cssButton' and @onclick='Export1()']");

		
		  WebElement selectOption = driver.findElement(exportBtnOfSearchCondition1);
		  JavascriptExecutor js = (JavascriptExecutor) driver;
		  js.executeScript("arguments[0].click();", selectOption); Thread.sleep(3000);
		 

		// General.executeScript(driver, "arguments[0].click();",
		// By.xpath("//input[@calss='cssButton' and @onclick='Export1()']"));

		Thread.sleep(10000);
	}

	/*
	 * 
	 * 
	 * @RFS-30 Feature: DIP-Automation-Story
	 * 
	 * #step1: Login the DIP system #step2: Unfold the DIP #step3: Unfold the Export
	 * #step4: Click the Icon of Stock Audit Report #step5: Select the value of Year
	 * Month "2019-09"at the Dealer Management page #step6: Input the NSC Code
	 * "35215"at the Dealer Management page #step7: Click the button of Search at
	 * the Dealer Management page #step8: There are several data in the Search
	 * Results at the Dealer Management page #step9: Click the button of Export at
	 * the Dealer Management page #step10: Click the button of Save
	 * as"theDealerManagementofStockAuditReport" at the Pop_up box #expected result:
	 * There is a Excel was downloaded
	 * 
	 * @RFS-72 Scenario Outline: DIP-AutoTC-Stock Audit Report Page-Check the Search
	 * by NSC Code and Export founction of Dealer Mangement Given Login the DIP
	 * system When Unfold the DIP And Unfold the Export And Click the Icon of Stock
	 * Audit Report And Select the value of Year Month "<yearmonth>"at Dealer
	 * Management of Stock Audit Report Page And Input the NSC Code "<nsc>"at Dealer
	 * Management of Stock Audit Report Page And Click the button of Search at
	 * Dealer Management of Stock Audit Report Page Then There are several data in
	 * Search Results at Dealer Management of Stock Audit Report Page When Click the
	 * button of Export at the Dealer Management of Stock Audit Report Page And
	 * Click the button of Save as "<importtemplatedownload>"at the Pop_up box Then
	 * There is a Excel was downloaded
	 * 
	 * Examples: |yearmonth|nsc |importtemplatedownload | |2019-09 |35215
	 * |theDealerManagementofStockAuditReport| *
	 */

	/*
	 * 
	 * @Given("^Login the DIP system$") public void login_the_DIP_system() throws
	 * Throwable {
	 * 
	 * DIPLogin login= new DIPLogin(driver); login.login();
	 * driver.switchTo().defaultContent(); Thread.sleep(10000); }
	 * 
	 * @When("^Unfold the DIP$") public void unfold_the_DIP() throws Throwable {
	 * 
	 * General.switchToFrame(driver, By.name("fraMenu")); sar.unfoldtheDIP();
	 * Thread.sleep(10000);
	 * 
	 * }
	 * 
	 * @When("^Click the Icon of Stock Audit Report$") public void
	 * click_the_Icon_of_Stock_Audit_Report() throws Throwable {
	 * sar.clicktheIconofStockAuditReport(); Thread.sleep(1000);
	 * 
	 * }
	 * 
	 */

	@When("^Select the value of Year Month \"([^\"]*)\"at Dealer Management of Stock Audit Report Page$")
	public void select_the_value_of_Year_Month_at_Dealer_Management_of_Stock_Audit_Report_Page(String yearmonth )
			throws Throwable {
        General.sendKeys(driver, By.name("YearMonth1"), yearmonth);
		Thread.sleep(1000);
	}

	@When("^Input the NSC Code \"([^\"]*)\"at  Dealer Management of Stock Audit Report Page$")
	public void input_the_NSC_Code_at_Dealer_Management_of_Stock_Audit_Report_Page(String nsc) throws Throwable {

		General.sendKeys(driver, By.name("NSCCODE"), nsc);
		Thread.sleep(1000);
	}

	@When("^Click the button of Search at  Dealer Management of Stock Audit Report Page$")
	public void click_the_button_of_Search_at_Dealer_Management_of_Stock_Audit_Report_Page() throws Throwable {
		General.executeScript(driver, "arguments[0].click();", By.xpath("//*[@onclick='query1()'and @value='Search']"));
		Thread.sleep(1000);
	}

	@Then("^There are several data in the Search Results at  Dealer Management of Stock Audit Report Page$")
	public void there_are_several_data_in_the_Search_Results_at_Dealer_Management_of_Stock_Audit_Report_Page()
			throws Throwable {

		String message = General.isPresentGetAlertext(driver);
		
		General.isPresentCloseAlert(driver, true);
		Thread.sleep(10000);
		List<WebElement> elements = driver.findElements(By.name("CaseGridRating1")); 
		int lenth = elements.size();
		
		System.out.println(lenth);

		//if (message.equals("No Result")) 
		if (message.indexOf("No Result")!=-1) 
		{
			Assert.assertEquals(0, lenth);
		} else {
			Assert.assertEquals(lenth != 0, lenth != 0);

		}
		Thread.sleep(1000);
	}

	/*
	 * 
	 	@When("^Click the button of Export at Dealer Management of the at Stock Audit Report Page$")
	public void click_the_button_of_Export_at_Dealer_Management_of_the_at_Stock_Audit_Report_Page() throws Throwable {

		 By exportBtnOfSearchCondition1 = By.xpath("//input[@class='cssButton' and @onclick='Export1()']");

		
		  WebElement selectOption = driver.findElement(exportBtnOfSearchCondition1);
		  JavascriptExecutor js = (JavascriptExecutor) driver;
		  js.executeScript("arguments[0].click();", selectOption); Thread.sleep(3000);
		 

		// General.executeScript(driver, "arguments[0].click();",
		// By.xpath("//input[@calss='cssButton' and @onclick='Export1()']"));

		Thread.sleep(10000);
	}
	  	 
	 * 
	 * @When("^Click the button of Save as \"([^\"]*)\"at the Pop_up box$") public
	 * void click_the_button_of_Save_as_at_the_Pop_up_box(String reportname) throws
	 * Throwable { Runtime downloadexe = Runtime.getRuntime(); try {
	 * General.cleanFolder(Hook.getDownloadPath());
	 * downloadexe.exec("C:/Windows/System32/cmd.exe /k start "
	 * +Hook.getDownloadTool()+" "+Hook.getDownloadPath()+reportname.replaceAll(" ",
	 * "").replaceAll("-", "")+"TemplateNew.xlsx"); // Download file
	 * Thread.sleep(10000); } catch (IOException e) { e.printStackTrace(); }
	 * Thread.sleep(10000); }
	 * 
	 * 
	 * @Then("^There is a Excel was downloaded$") public void
	 * there_is_a_Excel_was_downloaded() throws Throwable { // Write code here that
	 * turns the phrase above into concrete actions
	 * if(Hook.getDownloadPath().isEmpty()) { throw new
	 * Exception("Export monthly report Portfolio failed."); } else {
	 * System.out.println("Export report file successfully."); } }
	 *  
	 */
	
	/*
DIP_017_RSF71_StockAuditReportPage_ChecktheExportfounctionOfCreditAcceptance.feature
@RFS-30
Feature: DIP-Automation-Story

	#step1: Login the DIP system
	#step2: Unfold the DIP
	#step3: Unfold the Export
	#step4: Click the Icon of Stock Audit Report
	#step5: Select the value of Year Month at the Credit Acceptance page
	#step6: Click the button of Calculation at the Credit Acceptance page
	#step7: There are several data in the Search Results at the Credit Acceptance page
	#step8: Click the button of Export at the Credit Acceptance page
	#step9: Click the button of  Open at the Pop_up box
	# expected result: There is a Excel was opened
	@RFS-71
	Scenario Outline: DIP-AutoTC-Stock Audit Report Page-Check the Export founction Of Credit Acceptance
		Given Login the DIP system
		When Unfold the DIP
		And Unfold the Export
		And Click the Icon of Stock Audit Report
		And Select the value of Year Month"<yearmonth>" at Credit Acceptance of the Stock Audit Report Page
		And Click the button of Calculation at Credit Acceptance of the Stock Audit Report Page
		Then There are several data in the Search Results at Credit Acceptance of the Stock Audit Report Page
		When Click the button of Export at Credit Acceptance of the Stock Audit Report Page
	    And Click the button of Save as "<importtemplatedownload>"at the Pop_up box
		Then There is a Excel was downloaded
		
		Examples:
       |yearmonth|importtemplatedownload                  |
	   |2019-08  |ExportCreditAcceptanceofStockAuditRating| 
	 * */
	
	
	@When("^Select the value of Year Month\"([^\"]*)\" at Credit Acceptance of the Stock Audit Report Page$")
	public void select_the_value_of_Year_Month_at_Credit_Acceptance_of_the_Stock_Audit_Report_Page(String yearmonth) throws Throwable {

		General.sendKeys(driver, By.name("YearMonth"), yearmonth);
	
		
	}
	
	@When("^Click the button of Calculation at Credit Acceptance of the Stock Audit Report Page$")
	public void click_the_button_of_Calculation_at_Credit_Acceptance_of_the_Stock_Audit_Report_Page() throws Throwable {
        General.executeScript(driver, "arguments[0].click();", By.xpath("//*[@value='Calculation']"));
        Thread.sleep(1000);
        
	}
	
	@Then("^There are several data in the Search Results at Credit Acceptance of the Stock Audit Report Page$")
	public void there_are_several_data_in_the_Search_Results_at_Credit_Acceptance_of_the_Stock_Audit_Report_Page() throws Throwable {
      
    String message = General.isPresentGetAlertext(driver);
		
		General.isPresentCloseAlert(driver, true);
		Thread.sleep(10000);
		List<WebElement> elements = driver.findElements(By.name("CaseGrid1"));
		int lenth = elements.size();
		
		System.out.println(lenth);

		//if (message.equals("No Result")) 
		if (message.indexOf("No Result")!=-1) 
		{
			Assert.assertEquals(0, lenth);
		} else {
			Assert.assertEquals(lenth != 0, lenth != 0);

		}
		Thread.sleep(1000);
		
	}
	
	
	@When("^Click the button of Export at Credit Acceptance of the Stock Audit Report Page$")
	public void click_the_button_of_Export_at_Credit_Acceptance_of_the_Stock_Audit_Report_Page() throws Throwable {
		
	//	General.executeScript(driver, "arguments[0].click();", By.xpath("//input[@onclick='Export()'and @class='cssButton'"));
		
		 By exportBtnOfSearchCondition1 = By.xpath("//input[@class='cssButton' and @onclick='Export()']");

			
		  WebElement selectOption = driver.findElement(exportBtnOfSearchCondition1);
		  JavascriptExecutor js = (JavascriptExecutor) driver;
		  js.executeScript("arguments[0].click();", selectOption); 
		 
		  Thread.sleep(1000);
	}
	
	/*
	 * DIP_018_RFS74_StockAuditReportPage_ChecktheSearchbyRatingandExportfounctionofDealerMangementinStockAuditReportpage.feature
	@RFS-30
Feature: DIP-Automation-Story

	#step1: Login the DIP system
	#step2: Unfold the DIP
	#step3: Unfold the Export
	#step4: Click the Icon of Stock Audit Report
	#step5: Select the value of Year Month at the Dealer Management page
	#step6: Double click the select box of Rating at the Dealer Management page
	#step7: Select one kinds of rating at the Dealer Management page
	#step8: Click the button of Search at the Dealer Management page
	#step9: There are several data in the Search Results at the Dealer Management page
	#step10: Click the button of Export at the Dealer Management page
	#step11: Click the button of Open at the Pop_up box
	#expected result: There is a Excel was opened
	@RFS-74
	Scenario Outline: DIP-AutoTC-Stock Audit Report Page -Check the Search by Rating and Export founction of Dealer Mangement in Stock Audit Report page
		Given Login the DIP system
		When Unfold the DIP
		And Unfold the Export
		And Click the Icon of Stock Audit Report
		And Select the value of Year Month"<yearmonth>" at Dealer Management of the Stock Audit Report Page
		And Double click the select box of Rating at Dealer Management of the Stock Audit Report Page
		And Select one kinds of rating "<rating>"at Dealer Management of the Stock Audit Report Page
		And Click the button of Search at Dealer Management of the Stock Audit Report Page
		Then There are several data in the Search Results at Dealer Management of the Stock Audit Report Page
		When Click the button of Export at Dealer Management of the Stock Audit Report Page
	    And Click the button of Save as "<importtemplatedownload>"at the Pop_up box
		Then There is a Excel was downloaded
		
		Examples:
       |yearmonth|rating|importtemplatedownload                  |
	   |2019-08  |2     |ExportDealerManagementofStockAuditRating|	  
	 * */
	
	@When("^Double click the select box of Rating at Dealer Management of the Stock Audit Report Page$")
	public void double_click_the_select_box_of_Rating_at_Dealer_Management_of_the_Stock_Audit_Report_Page() throws Throwable {
		
	//	General.executeScript(driver, "arguments[0].click();", By.name("RatingCode1"));
		
		Actions action =new Actions(driver);
		
		action.doubleClick(driver.findElement(By.name("RatingCode1"))).perform();
		
		Thread.sleep(3000);
	   
	}	
	

@When("^Select one kinds of rating \"([^\"]*)\"at Dealer Management of the Stock Audit Report Page$")
public void select_one_kinds_of_rating_at_Dealer_Management_of_the_Stock_Audit_Report_Page(String rating) throws Throwable {
	
  // General.executeScript(driver, "arguments[0].removeAttribute('readOnly');", By.name("Rating1"));
	
	
	Select select =new Select(driver.findElement(By.name("codeselect")));

	select.selectByValue(rating);
		 
    Thread.sleep(3000);

}


	/*
	 * And Click the button of Save as "ExportDealerManagementofStockAuditRating"at
	 * the Pop_up box #
	 * DIPCheckStockAuditRatingPage.click_the_button_of_Save_as_at_the_Pop_up_box(
	 * String) Then There is a Excel was downloaded
	 */


/*
 * DIP_019_StockAuditReportPage_ChecktheSearchbyDealerShortNameandExportfounctioninDealerMangementofStockAuditReportPage.feature
@RFS-30
Feature: DIP-Automation-Story

	#step1: Login the DIP system
	#step2: Unfold the DIP
	#step3: Unfold the Export
	#step4: Click the Icon of Stock Audit Report
	#step5: Select the value of Year Month at the Dealer Management page
	#step6: Input the Dealer ShortName at the Dealer Management page
	#step6: Click the button of Search at the Dealer Management page
	#step7: There are several data in the Search Results at the Dealer Management page
	#step8: Click the button of Export at the Dealer Management page
	#step9: Click the button of Open at the Pop_up box
	#expected result: There is a Excel was opened
	@RFS-73
	Scenario Outline: DIP-AutoTC-Stock Audit Report Page-Check the Search by Dealer ShortName and Export founction in Dealer Mangement of Stock Audit Report Page
		Given Login the DIP system
		When Unfold the DIP
		And Unfold the Export
		And Click the Icon of Stock Audit Report
		And Select the value of Year Month "<yearmonth>"at Dealer Management of Stock Audit Report Page
		And Input the Dealer ShortName "<dealershortname>" at Dealer Management of Stock Audit Report Page
		And Click the button of Search at  Dealer Management of Stock Audit Report Page
		Then There are several data in the Search Results at  Dealer Management of Stock Audit Report Page
		When Click the button of Export at Dealer Management of the at Stock Audit Report Page
	    And Click the button of Save as "<importtemplatedownload>"at the Pop_up box
		Then There is a Excel was downloaded
		
		Examples:
         |yearmonth|dealershortname|importtemplatedownload                  |
	     |2019-09  |Yongjia Baozen |ExportDealerManagementofStockAuditRating|
 * */


@When("^Input the Dealer ShortName \"([^\"]*)\" at Dealer Management of Stock Audit Report Page$")
public void input_the_Dealer_ShortName_at_Dealer_Management_of_Stock_Audit_Report_Page(String dealershortname) throws Throwable {

   General.sendKeys(driver, By.name("DealerName"),dealershortname);
    Thread.sleep(3000);
}




/*
 *
 @RFS-30
Feature: DIP-Automation-Story

	#step1: Login the DIP system
	#step2: Unfold the DIP
	#step3: Unfold the Export
	#step4: Click the Icon of Stock Audit Report
	#step5: Select the value of Year Month at the Credit Acceptane page
	#step6: Input the Dealer ShortName at the Credit Acceptane page
	#step7: Click the button of Search at the Credit Acceptane page
	#step8: There are several data in the Search Results at the Credit Acceptane page
	#step9: Click the button of Export at the Credit Acceptane page
	#step10: Click the button of Open at the Pop_up box
	#expected result: There is a Excel was opened
	@RFS-76
	Scenario Outline: DIP-AutoTC- Stock Audit Report Page-Check the Search by Dealer ShortName and Export founction in Credit Acceptane  of Stock Audit Report Page
		Given Login the DIP system
		When Unfold the DIP
		And Unfold the Export
		And Click the Icon of Stock Audit Report
		And Select the value of Year Month"<yearmonth>" at Credit Acceptance of the Stock Audit Report Page
		And Input the Dealer ShortName "<dealershortname>" at Credit Acceptance of the Stock Audit Report Page
		And Click the button of Search at Credit Acceptance of the Stock Audit Report Page
		Then There are several data in the Search Results at Credit Acceptance of the Stock Audit Report Page
	   When Click the button of Export at Credit Acceptance of the Stock Audit Report Page
	   And Click the button of Save as "<importtemplatedownload>"at the Pop_up box
		Then There is a Excel was downloaded
		
	   Examples:
       |yearmonth|dealershortname|importtemplatedownload                  |
	   |2019-08  |Huangshi Baohui |ExportCreditAcceptanceofStockAuditRating|
 
 * */

@When("^Input the Dealer ShortName \"([^\"]*)\" at Credit Acceptance of the Stock Audit Report Page$")
public void input_the_Dealer_ShortName_at_Credit_Acceptance_of_the_Stock_Audit_Report_Page(String dealershortname) throws Throwable {
   
	General.sendKeys(driver, By.name("DealerShortName"), dealershortname);
   Thread.sleep(3000);
}

@When("^Click the button of Search at Credit Acceptance of the Stock Audit Report Page$")
public void click_the_button_of_Search_at_Credit_Acceptance_of_the_Stock_Audit_Report_Page() throws Throwable {
    General.executeScript(driver, "arguments[0].click();", By.xpath("//*[@value='Search'][1]"));
    Thread.sleep(3000);
}

/*
 DIP_021_RFS75_StockAuditReportPage_ChecktheSearchbyNSCCodeandExportfounctioninCreditAcceptaneofStockAuditReportPage.feature 
@RFS-30
Feature: DIP-Automation-Story

	#step1: Login the DIP system
	#step2: Unfold the DIP
	#step3: Unfold the Export
	#step4: Click the Icon of Stock Audit Report
	#step5: Select the value of Year Month at the Credit Acceptane page
	#step6: Input the NSC Code at the Credit Acceptane page
	#step7: Click the button of Search at the Credit Acceptane page
	#step8: There are several data in the Search Results at the Credit Acceptane page
	#step9: Click the button of Export at the Credit Acceptane page
	#step10: Click the button of Open at the Pop_up box
	#expected result: There is a Excel was opened
	@RFS-75
	Scenario Outline: DIP-AutoTC-Stock Audit Report Page-Check the Search by NSC Code and Export founction in Credit Acceptane of Stock Audit Report Page
		Given Login the DIP system
		When Unfold the DIP
		And Unfold the Export
		And Click the Icon of Stock Audit Report
		And Select the value of Year Month"<yearmonth>" at Credit Acceptance of the Stock Audit Report Page
		And Input the NSC Code "<nsc>" at Credit Acceptance of the Stock Audit Report Page
		And Click the button of Search at Credit Acceptance of the Stock Audit Report Page
		Then There are several data in the Search Results at Credit Acceptance of the Stock Audit Report Page
	    When Click the button of Export at Credit Acceptance of the Stock Audit Report Page
	    And Click the button of Save as "<importtemplatedownload>"at the Pop_up box
		Then There is a Excel was downloaded
			
	   Examples:
       |yearmonth|nsc   |importtemplatedownload                  |
	   |2019-08  |41595 |ExportCreditAcceptanceofStockAuditRating| 
 * */

@When("^Input the NSC Code \"([^\"]*)\" at Credit Acceptance of the Stock Audit Report Page$")
public void input_the_NSC_Code_at_Credit_Acceptance_of_the_Stock_Audit_Report_Page(String nsc) throws Throwable {
 
	General.sendKeys(driver, By.name("NSC_CODE"), nsc);
	Thread.sleep(3000);
}

/*
@RFS-30
Feature: DIP-Automation-Story

	#step1: Login the DIP system
	#step2: Unfold the DIP
	#step3: Unfold the Export
	#step4: Click the Icon of Stock Audit Report
	#step5: Select the value of Year Month at the Credit Acceptane page
	#step6: Double click the select box of Rating at the Credit Acceptane page
	#step7: Select one kinds of rating at the Credit Acceptane page
	#step8: Click the button of Search at the Credit Acceptane page
	#step9: There are several data in the Search Results at the Credit Acceptane page
	#step10: Click the button of Export at the Credit Acceptane page
	#step11: Click the button of Open at the Pop_up box
	#expected result: There is a Excel was opened
	@RFS-78
	Scenario: DIP-AutoTC-Stock Audit Report page-Check the Export function of Credit Acceptance
		Given Login the DIP system
		When Unfold the DIP
		And Unfold the Export
		And Click the Icon of Stock Audit Report
		And Select the value of Year Month"<yearmonth>" at Credit Acceptance of the Stock Audit Report Page
		And Double click the select box of Rating "<rating>" at Credit Acceptance of the Stock Audit Report Page
		And Select one kinds of rating at Credit Acceptance of the Stock Audit Report Page
		And Click the button of Search at Credit Acceptance of the Stock Audit Report Page
		Then There are several data in the Search Results at Credit Acceptance of the Stock Audit Report Page
	    When Click the button of Export at Credit Acceptance of the Stock Audit Report Page
	    And Click the button of Save as "<importtemplatedownload>"at the Pop_up box
		Then There is a Excel was downloaded
				
	Examples:
       |yearmonth|rating   |importtemplatedownload                  |
	   |2019-08  |4        |ExportCreditAcceptanceofStockAuditRating| 
 * */

@When("^Double click the select box of Rating at Credit Acceptance of the Stock Audit Report Page$")
public void double_click_the_select_box_of_Rating_at_Credit_Acceptance_of_the_Stock_Audit_Report_Page() throws Throwable {
    
	Actions action =new Actions(driver);	
	action.doubleClick(driver.findElement(By.name("RatingCode"))).perform();	
	Thread.sleep(3000);
}

@When("^Select one kinds of rating \"([^\"]*)\" at Credit Acceptance of the Stock Audit Report Page$")
public void select_one_kinds_of_rating_at_Credit_Acceptance_of_the_Stock_Audit_Report_Page(String rating) throws Throwable {
	Select select =new Select(driver.findElement(By.name("codeselect")));
	select.selectByValue(rating);		 
    Thread.sleep(3000);
}

/*
 * DIP_023_RFS69_StockAuditReportPage_ChecktheCalculationfounctionatCreditAcceptancepageofStockAuditReportPage.feature
@RFS-30
Feature: DIP-Automation-Story

	#step1: Login the DIP system
	#step2: Unfold the DIP
	#step3: Unfold the Export
	#step4: Click the Icon of Stock Audit Report
	#step5: Select the value of Year Month at the Credit Acceptance page 
	#step6: Click the button of Calculation at the Credit Acceptance page
	#expected result: There are several data in the Search Results at the Credit Acceptance page
	@RFS-69
	Scenario Outline: DIP-Stock Audit Report Page-Check the Calculation founction AutoTC-Credit Acceptance page of Stock Audit Report Page
		Given Login the DIP system
		When Unfold the DIP
		And Unfold the Export
		And Click the Icon of Stock Audit Report
		And Select the value of Year Month"<yearmonth>" at Credit Acceptance of the Stock Audit Report Page
		And Click the button of Calculation at Credit Acceptance of the Stock Audit Report Page
		Then There are several data in the Search Results at Credit Acceptance of the Stock Audit Report Page
		
	Examples:
       |yearmonth|
	   |2019-08  | 
 * */


/*
@RFS-30
Feature: DIP-Automation-Story

	#step1: Login the DIP system
	#step2: Unfold the DIP
	#step3: Unfold the Export
	#step4: Click the Icon of Stock Audit Report
	#step5: Select the value of Year Month at the Dearler Management page
	#step6: Click the button of Calculation at the Dearler Management page
	#expected result: There are several data in the Search Results at the Dearler Management page
	@RFS-68
	Scenario Outline: DIP-AutoTC-Stock Audit Report Page-Check the Calculation founction at Dealer Mangement page of Stock Audit Report Page
		Given Login the DIP system
		When Unfold the DIP
		And Unfold the Export
		And Click the Icon of Stock Audit Report
		And Select the value of Year Month "<yearmonth>"at Dealer Management of Stock Audit Report Page
		And Click the button of Calculation at the Dearler Management page
		Then There are several data in the Search Results at  Dealer Management of Stock Audit Report Page
		
	Examples:
       |yearmonth|
	   |2019-08  | 
 * */

@When("^Click the button of Calculate at the Dearler Management page$")
public void click_the_button_of_Calculation_at_the_Dearler_Management_page() throws Throwable {
	
   General.executeScript(driver, "arguments[0].click();", By.xpath("//*[@value='Calculate']"));
   Thread.sleep(3000);
   
}








}
