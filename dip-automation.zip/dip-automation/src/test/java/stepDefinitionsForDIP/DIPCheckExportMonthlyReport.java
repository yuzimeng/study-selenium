package stepDefinitionsForDIP;

import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import DIPPage.DIPLogin;
import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;


public class DIPCheckExportMonthlyReport {
	
	WebDriver driver=Hook.getDriver();
	/*
	 * @Given("^Login the DIP system$") public void login_the_DIP_system() throws
	 * Throwable { DIPLogin login= new DIPLogin(driver); login.login();
	 * 
	 * driver.switchTo().defaultContent(); driver.switchTo().frame("fraMenu"); }
	 */

	@Given("^Unfold the folder \"([^\"]*)\" and check next element \"([^\"]*)\" is displayed$")
	public void unfold_the_folder_and_check_next_element_is_displayed(String folderName, String verifiedItem) throws Throwable {
		if (!General.General.JudgingElementByContainsText(driver, verifiedItem))
		{
			//System.out.println("Folder Name:" + folderName+",  "+verifiedItem);
			String folderId = driver.findElement(By.xpath("//a[contains(text(),\'" + folderName + "\')]")).getAttribute("id");
			//System.out.println("Folder Name Id:" + folderId);
			driver.findElement(By.id(folderId)).sendKeys(Keys.ENTER);
		}
		else
		{
			By folderExisting=By.xpath("//a[contains(text(),\'" + folderName + "\')]");
			General.General.waitUntilvisiable(driver, 20, folderExisting);
			
			String folderId = driver.findElement(By.xpath("//a[contains(text(),\'" + folderName + "\')]")).getAttribute("id");
			driver.findElement(By.id(folderId)).sendKeys(Keys.ENTER);
		}
		Thread.sleep(5000);
		/*
		 * String menu=driver.findElement(By.id("divMenuTree")).getText();
		 * System.out.println("Menu List:"+menu);
		 * 
		 * String[] menuList=menu.split("\n"); System.out.println(menuList.length);
		 * 
		 * String folderMenuTree=""; // Child folder MainMenu > DIP for(int
		 * i=0;i<menuList.length;i++) { String
		 * tmpString="MenuTree_link_"+Integer.toString(i+1); String
		 * itemName=driver.findElement(By.id(tmpString)).getText();
		 * System.out.println("Current item name is: "+itemName); Thread.sleep(1000);
		 * if(itemName==folderName) { folderExpandId=tmpString;
		 * folderMenuTree="MenuTree_tree"+Integer.toString(i+1);
		 * System.out.println("Folder Expand Id"+folderExpandId); break; } }
		 * driver.findElement(By.id(folderExpandId)).sendKeys(Keys.ENTER);
		 */

	}

	@Given("^Click the Icon of  Monthly Report Portfolio \"([^\"]*)\"$")
	public void click_the_Icon(String monthlyReportPortfolio) throws Throwable {
		if (General.General.JudgingElementByContainsText(driver, monthlyReportPortfolio))
		{
			String monthlyReportPortfolioId = driver.findElement(By.xpath("//a[contains(text(),\'" + monthlyReportPortfolio + "\')]")).getAttribute("id");
			//System.out.println("Monthly Report Portfolio Id:" + monthlyReportPortfolioId);
			driver.findElement(By.id(monthlyReportPortfolioId)).sendKeys(Keys.ENTER);
		}
		Thread.sleep(5000);
		driver.switchTo().defaultContent();
		
		driver.switchTo().frame("fraInterface");
	    
	}

	@Given("^Select the value of Year-Month\"([^\"]*)\"$")
	public void select_the_value_of(String date) throws Throwable {
		By yearId=By.id("Year");
		General.General.waitUntilvisiable(driver, 20, yearId);
		driver.findElement(yearId).sendKeys(date);
		Thread.sleep(3000);
	}

	@When("^Click the \\[Export\\] button$")
	public void click_the_Export_button() throws Throwable {
	    By exportByClass=By.className("cssButton");
	    driver.findElement(exportByClass).click();
	    Thread.sleep(2000);
	}

	@When("^Click the button of popped box \"([^\"]*)\"$")
	public void click_the_button_of_popped_box(String reportCategory) throws Throwable {
		// Download file
		General.General.runToolWithCmd(Hook.getDownloadTool(), Hook.getDownloadPath(), reportCategory);
		Thread.sleep(3000);
	}
	
	@Then("^Verify the Excel has been exported$")
	public void verify_the_Excel_has_been_exported() throws Throwable {
		File file=new File(Hook.getDownloadPath());
		if(file.isDirectory())
		{
			if(file.list().length>0)
			{
				System.out.println("Verify Export report file successfully.");
			}
			else
			{
				throw new Exception("Verify Export report file failed.");
			}
		}
		else {
			throw new Exception("Verify the directory whether it is not existing.");
		}
	}



}
