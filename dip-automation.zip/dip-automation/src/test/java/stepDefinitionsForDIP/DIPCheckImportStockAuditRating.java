package stepDefinitionsForDIP;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class DIPCheckImportStockAuditRating {
	
	WebDriver driver=Hook.getDriver();
	
	@Given("^Click the Icon of Stock Audit Rating \"([^\"]*)\"$")
	public void click_the_Icon_of_Stock_Audit_Rating(String stockAuditRating) throws Throwable {
		if (General.General.JudgingElementByContainsText(driver, stockAuditRating))
		{
			String stockAuditRatingId = driver.findElement(By.xpath("//a[contains(text(),\'" + stockAuditRating + "\')]")).getAttribute("id");
			driver.findElement(By.id(stockAuditRatingId)).sendKeys(Keys.ENTER);
		}
		Thread.sleep(5000);
		driver.switchTo().defaultContent();
		
		driver.switchTo().frame("fraInterface");
	}

	@Given("^Select the value of Year-Month \"([^\"]*)\" for Credit Acceptance$")
	public void select_the_value_of_Year_Month_for_Credit_Acceptance(String date) throws Throwable {
		By yearId=By.id("Year");
		General.General.waitUntilvisiable(driver, 20, yearId);
		driver.findElement(yearId).sendKeys(date);
		Thread.sleep(3000);
	}

	@Given("^Click the button of \\[Browser\\] for Credit Acceptance page$")
	public void click_the_button_of_Browser_for_Credit_Acceptance_page() throws Throwable {
	    By browserBtn=By.name("FileName");
	    WebElement browser = driver.findElement(browserBtn);
		Actions action_Credit_Acceptance = new Actions(driver);
		action_Credit_Acceptance.moveToElement(browser);
		action_Credit_Acceptance.doubleClick(browser).perform();
		Thread.sleep(3000);
	}

	@Given("^Select one file \"([^\"]*)\" that you want to import with Credit Acceptance$")
	public void select_one_file_that_you_want_to_import_with_Credit_Acceptance(String fileName) throws Throwable {
		Runtime uploadexe = Runtime.getRuntime();
		try {
			Thread.sleep(5000);
			uploadexe.exec(Hook.getUploadTool()+" "+Hook.getUploadPath() + fileName);  //Upload file
			Thread.sleep(10000);
		} catch (IOException e) {
			e.printStackTrace();
		}
		Thread.sleep(5000);
	}

	@Given("^Click the button of \\[Import\\] for Credit Acceptance$")
	public void click_the_button_of_Import_for_Credit_Acceptance() throws Throwable {
	    By importBtn=By.xpath("//input[@class='cssButton' and @onclick='Import();']");
	    //driver.findElement(importBtn).click();
	    
	    WebElement selectOption = driver.findElement(importBtn);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].click();", selectOption);
	    Thread.sleep(5000);
	    
	}

	@Given("^Click the button of \\[OK\\] at the Pop_up box$")
	public void click_the_button_of_OK_at_the_Pop_up_box() throws Throwable {
		Thread.sleep(10000);
		driver.switchTo().alert().accept();; //Switch to Alert window
		
		Robot robot = new Robot();
		robot.keyPress(KeyEvent.VK_ENTER);  // Click "OK" button
		Thread.sleep(5000);

	}

	@Then("^Verify the file imported \"([^\"]*)\" shows in Reminder Information of Credit Acceptance$")
	public void verify_the_file_imported_shows_in_Reminder_Information_of_Credit_Acceptance(String fileName) throws Throwable {
		
		By lastPageBtn = By.xpath("//img[@name='btnchangepage' and @src='https://dip-test.bmwgroup.net/dip-test/common/images/lastPage.gif']");
		WebElement clickLastPageBtn = driver.findElement(lastPageBtn);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].click();", clickLastPageBtn);
		Thread.sleep(5000);

		By tableField = By.xpath("//input[@name='ImportInfoGrid2' and @class='mulreadonly'][last()]");
		String lineOneData = driver.findElement(tableField).getAttribute("value");

		if (lineOneData != "") {
			if (lineOneData.indexOf(fileName) != -1) {
				System.out.println("Verify Import Credit Acceptance file successfully.");
			} else {
				throw new Exception("Verify Import Credit Acceptance file failed.");
			}
		} else {
			throw new Exception("Import Credit Acceptance failed.");
		}

	}
	

}
